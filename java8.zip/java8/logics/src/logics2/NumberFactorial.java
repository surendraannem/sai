package logics2;

public class NumberFactorial {
	public static void main(String[] args) {
		int i=6;
		int fact=1;
		for(i=1;i<=6;i++) {
			fact=fact*i;
		}
		System.out.println("6! is.."+fact);
	}

}
