package logics2;

public class StringPrint {
	public static void main(String[] args) {
		//String name="saikiran";
		char[] ch= {'s','a','i'};
		for(int i=0;i<=ch.length;i++) {
			
		}
		System.out.println(ch);
	}

}
;