package logics2;

public class StringPoligram {
	public static void main(String[] args) {
		String name="madam";
		String rev="";
		for(int i=name.length()-1;i>=0;i--) {
			rev=rev+name.charAt(i);	
			
		}if(name.equals(rev)) {
			System.out.println("accet");
		}else {
			System.out.println("not accept");
		}
		System.out.println("rev name is..."+rev);
		System.out.println("hash code of name.."+name.hashCode()); 
		System.out.println("hash code of rev name.."+rev.hashCode());
		
		
	}

}
