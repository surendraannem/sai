package logics2;

public class Swipping {
	public static void main(String[] args) {
		int i=12;
		int j=8;
		i=i+j;//i=20
		j=i-j;// j=12
		i=i-j;//i=8
		System.out.println("i value is..."+i+" j value is...."+j);
		
	}

}
