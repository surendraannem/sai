package logics2;

public class StringReverce {
	public static void main(String[] args) {
		
	
	String name="saikiran";
	String rev="";
	for(int i=name.length()-1;i>=0;i--) {
		rev=rev+name.charAt(i);
		
		
	}
	System.out.println("reverese val is"+rev);
	
	StringBuffer bf=new StringBuffer("saikiran");
	System.out.println(bf.reverse());
	}
}
