package logics;

public class NumberPoligram {
	public static void main(String[] args) {
		int num=1001;
		int revnum=0;
		int reminder;
		int revval=num;
		while(num!=0) {
			reminder=num%10;
			revnum=revnum*10+reminder;
			num=num/10;
			
		}
		if(revnum==revval) {
			System.out.println("it is polidrome");
		}else {
			System.out.println("it is not polidrome");
		}
		System.out.println("rev val is..."+revval);
	}

}
