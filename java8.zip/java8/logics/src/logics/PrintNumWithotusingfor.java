package logics;

public class PrintNumWithotusingfor {
	
	public static void printnum(int i) {
		System.out.println(i);
		
		if(i<10) {
			printnum(i+1);
			
		}		
	}
	public static void main(String[] args) {
		PrintNumWithotusingfor.printnum(1);
	}

}
