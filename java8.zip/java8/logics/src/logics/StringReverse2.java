package logics;

public class StringReverse2 {
	public static void main (String [] args){
		
		String name= "sai kiran";
		
		String rev="";
		
		for (int i=length-1;i>=0;i--){
			
		rev= rev+name.charAt(i);
		}
			
			System.out.println("revarse value is"+rev);	
			
	}
	}


