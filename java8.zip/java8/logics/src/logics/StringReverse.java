package logics;

public class StringReverse {
	public static void main(String[] args) {
		String name="saikiran";
		String rev="";
		
		for(int i=name.length()-1;i>=0;i--) {
			rev=rev+name.charAt(i);
		}	
		System.out.println("i value is.... "+rev);
		
		String name1="anilkumar";
		String rev1="";
		for( int j=name1.length()-1;j>=0;j--) {
			rev1=rev1+name1.charAt(j);
			
		}
		System.out.println("j value is..."+rev1);
	
		}
	}


