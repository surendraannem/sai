package logics;

public class NumberFactroial {
	public static void main(String[] args) {
		int val=6;
		int fact=1;
		for(int i=1;i<=val;i++) {
			fact=fact*i;
		}
		System.out.println("fact val is...."+fact);
	}
}

