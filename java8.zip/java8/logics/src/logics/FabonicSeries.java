package logics;

public class FabonicSeries {
	public static void main(String[] args) {
		int val=10;
		int a=0;
		int b=1;
		int c=1;
		for(int i=1;i<=val;i++) {
			System.out.println("i value is...."+a);
			
		a=b;
		b=c;
		c=a+b;
	}

}
}