package logics;

public class SpringPalidrome {
	public static void main(String[] args) {
		
	
	String name="mom";
	String rev="";
	for (int i=name.length()-1;i>=0;i--) {
		rev=rev+name.charAt(i);
			}
	System.out.println("name is..."+rev);
	if(name.equals(rev)) {
		System.out.println("it is polidrome...");
	}else {
		System.out.println("it is not polidrome");
	}

}
}