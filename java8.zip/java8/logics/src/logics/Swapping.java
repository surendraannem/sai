package logics;

public class Swapping {
	
	public static void main(String[] args) {
		
		
		int i=5;
		int j=8	;
	      j=i;
	      i=j+3;
	     // System.out.println("i value is..."+i);
	    //System.out.println("j value is..."+j);        
	  	
	}
	


}
