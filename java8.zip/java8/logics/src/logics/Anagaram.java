package logics;

import java.sql.Array;
import java.util.Arrays;

public class Anagaram {
	public static void main(String[] args) {
		// covert string all lower case
		// comapres lenth equal or not
		// string conevrt in array
		// sort the array
		// equal the array
		
		String str1="Anagram";
		String str2="nagaram";
		str1= str1.toLowerCase();
		str2= str2.toLowerCase();
		
		if(str1.length()==str2.length()) {
			
			
		   char[] arry1  =str1.toCharArray();
		   char[] arry2  =str2.toCharArray();
		   
		   Arrays.sort(arry1);
		   Arrays.sort(arry2);
		 boolean result = Arrays.equals(arry1, arry2);
		 if(result) {
			System.out.println("this is anagram"); 
		 }else {
			 System.out.println("this is  not anagaram");
		 }
			
		}else {
			System.out.println("it is not anagram");
		}
		
	}

}
