package features;

public class Employee implements Manager, TeamLeader {

	@Override
	public String lead() {
		
		return Manager.super.lead();
	}
public static void main(String[] args) {
	Employee e=new Employee();
	System.out.println(e.lead());
	System.out.println(Manager.role());
	System.out.println(TeamLeader.role());
}
}
