package features;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class AllFundamentalClass {
	public static void main(String[] args) {
		// with lamda consumer
			Consumer<String> con1= t ->System.out.println("name is...."+t);
		    con1.accept("sai kiran dasari");
		 // with lamda supplier
			Supplier<String> sup1=()-> "saikiran dasari";
				
		   System.out.println("name is..."+sup1.get());
		// with lamda prdicate
			Predicate<String> pre1 =t-> t.equals("sai");
		   boolean data1=pre1.test("sai");
		  System.out.println(data1);
		// with lamda function
		    Function<String, Double> fun1= t ->25000.34;
		    Double cost1=fun1.apply("i phone prise is");
		    System.out.println(cost1);

}
}