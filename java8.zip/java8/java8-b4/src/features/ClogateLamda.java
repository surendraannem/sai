package features;
@FunctionalInterface
public interface ClogateLamda {
	
	void colgate(int cost, String taste);
	
	public static void main(String[] args) {
		
		ClogateLamda cl=new ClogateLamda() {
			
			@Override
			public void colgate(int cost, String taste) {
				System.out.println("cost is.."+cost+"     taste is.."+taste);
					
			}
		};
		cl.colgate(50, "salt");
ClogateLamda cl2=(int cost, String taste)-> 
				System.out.println("cost is.."+cost+"     taste is.."+taste);
				cl.colgate(150, "salt& sweet");
		
	}

}
