package features;

public interface TeamLeader {
	default String lead() {
		return "team lead";
	}
	
	static String role() {
		return "team role";
	}
	
	

}
