package features;
@FunctionalInterface
public interface FundamentalInterface {
	
	void student(String name);
	public static void main(String[] args) {
		
		FundamentalInterface fi=new FundamentalInterface() {
			
			@Override
			public void student(String name) {
				System.out.println("student name is.."+name);
				
			}
		};
		fi.student("sai kiran");
FundamentalInterface fi1=name-> 
				System.out.println("student name is.."+name);
				fi1.student("moji");
}

}
