package features;

public interface Manager {

	default String lead() {
		return "manager lead";
	}
	
	static String role() {
		return "manager role";
	}
	
	
}
