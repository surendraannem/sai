package features;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.util.Date;
import java.util.Set;

public class TimeApi {
	
	public static void main(String[] args) {
		Date d=new Date();
		System.out.println(d);
		LocalDate ld=LocalDate.now();
		System.out.println("date is...."+ld);
		LocalTime lt=LocalTime.now();
		System.out.println("time is...."+lt);
		LocalDateTime ldt=LocalDateTime.now();
		System.out.println("time and date is..."+ldt);
	LocalDate ld1	=LocalDate.of(2022, Month.FEBRUARY, 29);
	System.out.println(ld1);
	Set<String> zones=ZoneId.getAvailableZoneIds();
	//zones.stream().forEach(System.out::println);
	LocalDateTime idtzone=LocalDateTime.now(ZoneId.of("Asia/Kolkata"));
	System.out.println(idtzone);
	}

}
