package features;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FunctionalInterface1 {
	public static void main(String[] args) {
		// with out lamda consumer
	
		Consumer<String> con=new Consumer<String>() {

			@Override
			public void accept(String t) {
				//System.out.println("name is...."+t);
						
			}	
			
		};con.accept("sai kiran");
		// with lamda consumer
		Consumer<String> con1= t ->System.out.println("name is...."+t);
			//con1.accept("sai kiran dasari");
		// with out lamda suppiler	
		Supplier<String> sup=new Supplier<String>() {

			@Override
			public String get() {
				
				return "saikiran";
			}
			
		};	//System.out.println("name is..."+sup.get());
		
		// with lamda supplier
		Supplier<String> sup1=()-> "saikiran dasari";
			
			//System.out.println("name is..."+sup1.get());
		
		// without lamda predicate
		
		Predicate<String> pre =new Predicate<String>() {

			@Override
			public boolean test(String t) {
				boolean val=t.equals("sai");
				return val;
			}
		};
	boolean data=pre.test("kiran");
	//System.out.println(data);
	
	// with lamda 
	Predicate<String> pre1 =t-> t.equals("sai");
boolean data1=pre1.test("sai");
//System.out.println(data1);

// without lamda-function
Function<String, Double> fun=new Function<String, Double>() {

	@Override
	public Double apply(String t) {
		
		return 15000.34;
	}
};
Double cost=fun.apply("i phone prise is");
System.out.println(cost);

// with lamda function
Function<String, Double> fun1= t ->25000.34;

Double cost1=fun1.apply("i phone prise is");
System.out.println(cost1);
		
				
	}
}
