package features;
@FunctionalInterface
public interface Employelamda {
	
	void empname(String name);
	
	public static void main(String[] args) {
		Employelamda el=new Employelamda() {
			
			@Override
			public void empname(String name) {
				System.out.println("employee name is.."+name);
		
			}
		};
		el.empname("ajay");
Employelamda el2= name-> 
				System.out.println("employee name is.."+name);
		el2.empname("subani");
	}

}
