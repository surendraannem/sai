package features;

public enum Week {
	sunday,monday, tuesday, thursday, friday, saturday;
	
	public static void main(String[] args) {
		System.out.println(sunday);
	}

}
