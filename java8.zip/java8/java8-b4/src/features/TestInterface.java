package features;

public interface TestInterface {
	
	void product(String name);
	
	public static void main(String[] args) {
		TestInterface ti=new TestInterface() {
			
			@Override
			public void product(String name) {
				System.out.println("product name is.."+name);
				
				
			}
		};
		ti.product("santoor saop");
	}

}
