package test;

import java.util.Arrays;
import java.util.List;

public class StringReverce1 {
	public static void main(String[] args) {
		
		String name="i am kopparru village";
		String rev="";
		for(int i=name.length()-1;i>=0;i--) {
			
			rev=rev+name.charAt(i);	
		}
		//System.out.println(" revare value is..."+rev);
		
		List<String> list=Arrays.asList(name);
		list.stream().map(x-> new StringBuilder(name).reverse())
		.forEach(System.out::println);
		
		
	}

}
