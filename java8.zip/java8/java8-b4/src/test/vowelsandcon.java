package test;

import java.util.Arrays;
import java.util.List;

public class vowelsandcon {
	public static void main(String[] args) {
		String name="i Am Kopparru village";
		      String lc=name.toLowerCase();
		      System.out.println(lc);
		      System.out.println(lc.concat("  my name is sai"));
		      System.out.println(lc.charAt(3));
		      System.out.println(lc.startsWith("i"));
		      System.out.println(lc.replace("a", "b"));
		      
		StringBuilder name1=new StringBuilder("sai kiran");
		System.out.println(name1.insert(1, "b"));
		System.out.println(name1.reverse());
		System.out.println(name1.indexOf("a"));
		
		String name2="welcome to teja it";
		Character[] c= {'a','e','i','o','u'};
		List<Character> vowels=Arrays.asList(c);
		long vc=name2.chars().filter(x-> vowels.contains((char)x)).count();
		System.out.println("vowels count is.."+vc);
		long vc1=name2.chars().filter(x-> !vowels.contains((char)x)).count();
		System.out.println("non vowels count is.."+vc1);
		
		
		
		
		
		      
		      
		      
	}

}
