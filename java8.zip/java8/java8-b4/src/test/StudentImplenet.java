package test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StudentImplenet {
	public static void main(String[] args) {
		
	
	Student s1=new Student(1, "sai", 23);
	Student s2=new Student(2, "sundeep", 22);
	Student s3=new Student(4, "moji", 26);
	Student s4=new Student(1, "kesava", 21);
	
	List<Student> list=Arrays.asList(s1,s2,s3,s4);
	list.stream()
	//.filter(x-> x.getName().equals("sai"))
	//.filter(x-> x.getAge()>(20))
	//.filter(x-> x.getSid()>(2))
	//.map(x-> x.getAge()+5)
	.distinct()
	.skip(1)
	.limit(2)
	.forEach(System.out::println);
	
	List<Student> list1=list.stream().collect(Collectors.toList());
	System.out.println("================");
	Boolean am=list1.stream().anyMatch(x-> x.getName().equals("sai"));
	System.out.println("any match......"+am);
	Optional<Student> ff=list1.stream().findFirst();
	System.out.println("find first"+ff.get());
	int ga=list1.stream().mapToInt(x->x.getAge()+5).sum();
	System.out.println(ga);
	list1.stream().map(x-> x.getName().contains("s")).forEach(System.out::println);
	
	
	
	
	
	
	
}
}