package setToMap;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StudentList {
	public static void main(String[] args) {
		
	
	
	Student s1=new Student(1, "sai", 26);
	Student s2=new Student(2, "subani", 28);
	Student s3=new Student(3, "moji", 27);
	Student s4=new Student(4, "shareef", 26);
	
	List<Student> list=Arrays.asList(s1,s2,s3,s4);
	Map<Integer, Student> map=new HashMap();
	// before java 8
	for (Student student : list) {
		
		map.put(student.getRollnum(), student);
		
		//in java 8
		
		
		Map<Integer, Student> map1=list.stream()
		.collect(Collectors.toMap(Student::getRollnum, Function.identity()));
		map1.forEach(null);
		
	}

}
}