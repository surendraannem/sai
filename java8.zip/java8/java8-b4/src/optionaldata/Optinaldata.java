package optionaldata;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Optinaldata {
	
	public static void main(String[] args) throws Exception {
		
		User ur=new  User(1, null, 27);
		
		//System.out.println(ur.getUsername());
		
		if(ur.getUsername()!=null) {
			
			//System.out.println(ur.getUsername().toUpperCase());
			
		}else {
			String defaultname="default data";
			//System.out.println(" no data in user name..."+defaultname);
		}	
		
		
      Optional<String> optdata= Optional.ofNullable(ur.getUsername());
      
      System.out.println(optdata.orElse("deafult data...").concat("from teja it"));
      if (optdata.isPresent()) {
    	  System.out.println(optdata.get());
      }
      System.out.println(optdata.orElseThrow(()->new Exception("user not avillable")));
		}
	
	
}
