package StreamApi;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;import java.util.stream.Collector;
import java.util.stream.Collectors;

public class NumbersExamples1 {
	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(1,3,4,6,7,9,11,13,14,17,19);
		list.stream()
		.filter(t->t%2==0)
		.map(t-> t+5)
		.sorted()
		.sorted(Comparator.reverseOrder())
		.distinct()
		.skip(1)
		.limit(2)
		.forEach(System.out::println);
		System.out.println("===============");
		List<Integer> list1=list.stream().collect(Collectors.toList());
		list1.stream().forEach(System.out::println);
		Optional<Integer>fa=list1.stream().findAny();
		System.out.println("finad any...."+fa.get());
		Optional<Integer> ff=list1.stream().findFirst();
		System.out.println("find any.."+ff.get());
		Boolean am=list1.stream().anyMatch(t-> t/2==0);
		System.out.println("any match...."+am);
		Boolean allmatch=list1.stream().allMatch(t-> t%2==0);
		System.out.println("all match is..."+allmatch);
		Boolean nm=list1.stream().noneMatch(t-> t==14);
		System.out.println("non match...."+nm);
		Optional<Integer> max=list1.stream().max(Integer::compare);
		System.out.println("max value is..."+max.get());
		Optional<Integer> min=list1.stream().min(Integer::compare);
		System.out.println("min value is..."+min.get());
		int sum=list1.stream().mapToInt(t-> t+5).sum();
		System.out.println(" sum value is.."+sum);
		OptionalDouble avg=list1.stream().mapToInt(t-> t+2).average();
		System.out.println("avarage......."+avg.getAsDouble());
		long count=list1.stream().count();
		System.out.println("count elements...."+count);
		
		List<Integer> list2=list1.stream().collect(Collectors.toList());
		list2.stream().distinct().sorted().skip(8).forEach(System.out::println);
list2.stream().sorted(Comparator.reverseOrder()).skip(1).limit(1).forEach(System.out::println);	
		
		
		
	}

	}


