package StreamApi;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class StringLogics {
	public static void main(String[] args) {
		List<String> list=Arrays.asList("sai","subani","shareef","moji","prasanth");
	
	long count=list.stream().count();
	System.out.println("elements count is....."+count);
	
	long equlvalues=list.stream().filter(x-> x.equals("sai")).count();
	System.out.println("equal values is....."+equlvalues);
	
	
	long uniquevalues=list.stream().distinct().count();
	System.out.println("unique values is..."+uniquevalues);
	// print distinct values.. ad set
	Set<String> set=new HashSet<String>();
	list.stream().filter(x-> !set.add(x) ).forEach(System.out::println);
	
	String name="sai kiran dasari";
	long sm=name.chars().filter(x-> x=='s').count();
	System.out.println(sm);
	// total charcter values
	
	long chars=name.chars().filter(x-> x!=' ').count();
	
	System.out.println("chars count is.."+chars);
	
	
	

	
	
	
	
	
	
	
	
	}

}
