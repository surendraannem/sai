package StreamApi;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StringReverce {
	public static void main(String[] args) {
		
	String name=" Welcome to Teja It";
	
	String revdata=Arrays.asList(name.split(" "))
			.stream()
	         .map(x-> new StringBuilder().reverse()) 
	         .collect(Collectors.joining(" "));
	System.out.println(" reverese data is"+revdata);
			      
	
	
	
	}	

}
