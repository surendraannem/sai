package StreamApi;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StringExamples1 {
	public static void main(String[] args) {
		List<String> list=Arrays.asList("sai","subani","moji","shareef","prasanna","kesava","ajay","sandeep");
	       list.stream()
	      // .filter(t-> t.startsWith("s"))
	       //.map(t-> t.equals("sai"))
	       .distinct()
	       .skip(2)
	       .limit(4)
	       .forEach(System.out::println);
	       System.out.println("================");
	       List<String> list1=list.stream().collect(Collectors.toList());
	       list1.stream().forEach(System.out::println);
	      Boolean am =list1.stream().anyMatch(t-> t.equals("subani"));
	      System.out.println("any match...."+am);
	     Boolean all= list1.stream().allMatch(t-> t.equals("moji"));
	     System.out.println("all match...."+all);
	    Boolean nm =list1.stream().noneMatch(t-> t.equals("sandeep k"));
	    System.out.println(" non match ...."+nm);
	    Optional<String> ff1=list1.stream().findFirst();
	    System.out.println(" find first.."+ff1.get());
	    List<String> list3=list1.stream().collect(Collectors.toList());
	    System.out.println("========");
	   Long co= list3.stream().count();
	   System.out.println("count is..."+co);
	    list3.stream().distinct().sorted().skip(2).limit(1) .forEach(System.out::println);
	    
	    
	    
	       
	}

}
