package StreamApi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class EmployeeStreamdata {
	public static void main(String[] args) {
EmployeeData ed1=new EmployeeData("sai kiran", "hyderabad", 1500000);
EmployeeData ed2=new EmployeeData("subani", "kopparu", 1400000);
EmployeeData ed3=new EmployeeData("shareef", "amaravathi", 1200000);
EmployeeData ed4=new EmployeeData("moji", "achampeta", 1300000);
  List<EmployeeData> ed=Arrays.asList(ed1,ed2,ed3,ed4);
  ed.stream()
 // .filter(x-> x.getEmpname().equals("sai kiran"))
  .map(x->x.getLocation() )
  .distinct()
  .skip(1)
  .limit(3)
  .forEach(System.out::println);
 List<EmployeeData> emp=Arrays.asList(ed1,ed2,ed3,ed4);
 System.out.println("=====================");
 emp.stream().forEach(System.out::println);
 Boolean am3=emp.stream().anyMatch(x-> x.getEmpname().endsWith("n"));
 System.out.println("any match ..."+am3);
 Optional<EmployeeData> fa=emp.stream().findAny();
 System.out.println("find any.."+fa.get());
 int sum=emp.stream().mapToInt(x-> x.getSalary()+50000).sum();
 System.out.println("salary sum...."+sum);
 Optional<EmployeeData> =emp.stream().map(x-> x.getSalary()).max(Integer::compare);
 
 
 
 
 
 
 
 
 
 

}
}