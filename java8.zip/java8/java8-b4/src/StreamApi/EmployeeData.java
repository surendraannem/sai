package StreamApi;

public class EmployeeData {
	String empname;
	String location;
	Integer salary;
	public EmployeeData(String empname, String location, int salary) {
		super();
		this.empname = empname;
		this.location = location;
		this.salary = salary;
	}
	public String getEmpname() {
		return empname;
	}
	@Override
	public String toString() {
		return "EmployeeData [empname=" + empname + ", location=" + location + ", salary=" + salary + ", getEmpname()="
				+ getEmpname() + ", getLocation()=" + getLocation() + ", getSalary()=" + getSalary() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}

}
