package StreamApi;

import java.util.Arrays;import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class NumberExamples {
	public static void main(String[] args) {
		//-> consumer print the data
		IntStream.range(1, 11).forEach(t-> System.out.println("values is"+t));
	IntStream.range(1, 15).parallel().forEach(t->System.out.println("value is"+t));
	//-> pedicate filter the data
		IntStream.range(1,20).filter(t->t%2==0).forEach(System.out::println);
	
	List<Integer> list=Arrays.asList(1,5,23,5,8,10,32,56,54,62,43,87,44,68);
	     list.stream()
	                   .filter(x->x%2==0)// flter the data based condition
	                   .map(t->t*5)// apply logic
	                   .distinct()// given unique data
	                   .sorted(Comparator.reverseOrder())// to sort data
	                   .skip(1)// will skip n number of elements
	                   .limit(5)// will show n number elements in display
	                   
	                
	                   .forEach(System.out::println);
	    
	     // iterate elements and print
	     
			                   //clas name  // method name-> method refernce
	     System.out.println("========================");
	    List<Integer> distlist =list.stream().distinct().collect(Collectors.toList());
	     
	distlist.stream().filter(x->x%2==0).forEach(System.out::println);
	System.out.println("===============================================");
	Optional<Integer> max=list.stream().max(Integer::compare);
	System.out.println("max value is..."+max.get());
	Long count=list.stream().count();
	System.out.println("count value is....."+count);
	OptionalDouble avg=list.stream().mapToInt(x->x+5).average();
	System.out.println("avg value is....."+avg.getAsDouble());
	int sum=list.stream().mapToInt(x->x*5).sum();
	System.out.println("sum value is......"+sum);
	Optional<Integer > findany=list.stream().findAny();
	System.out.println("finad any value is..."+findany.get());
	Optional<Integer> findfirst=list.stream().findFirst();
	System.out.println("find first value is...."+findfirst.get());
	Boolean allmatch=list.stream().allMatch(x-> x==24);
	System.out.println("all match value is...."+allmatch);
    Boolean anymatch	=list.stream().anyMatch(x-> x== 5);
    System.out.println("any match value is..."+anymatch);
    Boolean nonmatch=list.stream().noneMatch(x-> x==11);
    System.out.println("non match is......"+nonmatch);
	
	
	
	
	
	
	
	
	}

}
