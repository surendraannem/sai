package StreamApi;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMap {
	public static void main(String[] args) {
		List<Integer> list1=Arrays.asList(1,5,7,9,10,23,34);
		List<Integer> list2=Arrays.asList(9,5,7,9,34,23,34);
		List<Integer> list3=Arrays.asList(12,555,7,92,10,23,34);
		List<Integer> list4=Arrays.asList(17,25,7,29,10,23,84);
		
		List<List<Integer>> li=Arrays.asList(list1,list2,list3,list4);
		//li.stream().forEach(System.out::println);
		List<Integer> list=li.stream().flatMap(x-> x.stream()).collect(Collectors.toList());
	         list.stream().sorted().filter(x-> x>10).forEach(System.out::println);
	}

}
