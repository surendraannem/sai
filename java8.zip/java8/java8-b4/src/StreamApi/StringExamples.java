package StreamApi;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class StringExamples {
	
	public static void main(String[] args) {
		
		List<String> list=Arrays.asList("sai","subani","shareef","prasanth","anil");
		
		             list.stream()
		                // .filter(x-> x.startsWith("s"))
		                 //  .map(x-> x.toLowerCase())
		                //   .distinct()
		                //   .sorted(Comparator.reverseOrder())
		               //    .skip(2)
		                //   .limit(3)
		                     
		                     .forEach(System.out::println);
		          System.out.println("==============");
		           Optional<String> findany =list.stream().findAny();
		           System.out.println("find any value is.."+findany.get());
		         Optional<String> findfirst = list.stream().findFirst();
		         System.out.println("first value is..."+findfirst.get());
		        Boolean allmatch= list.stream().allMatch(x-> x.equals("sai"));
		        System.out.println("all match value is"+allmatch);
		      Boolean anymatch = list.stream().anyMatch(x-> x.equals("subani"));
		       System.out.println("any match value is..."+anymatch);  
		      Boolean nonmatch =list.stream().noneMatch(x-> x.equals("prasanth it"));
		            System.out.println("non match value is.."+nonmatch);
		                 
		             
		
		
		
		
		
		
	}
	


}
