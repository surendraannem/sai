package StreamApi;

import java.util.Arrays;
import java.util.List;

public class VowelsAndConsonents {
	public static void main(String[] args) {
		
		String name=" This Is Teja It";
		String input=name.toLowerCase();
		System.out.println(input);
		List<Character> vowels=Arrays.asList('a','e','i','o','u');
		long vc=input.chars().filter(ch-> vowels.contains((char)ch)).count();
	  System.out.println("vowels count is...."+vc);	
	  long vc1=input.chars().filter(ch-> !vowels.contains((char)ch)).filter(x->x!=' ').count();
	System.out.println(" constarins is.."+vc1);
	
	
	
	}

}
