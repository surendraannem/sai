package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DynamicOperations {
	
	
	public void saveemployee() throws SQLException  {
		Connection con=null;
		
		con=JdbcUtil.createConnection();
		
		String insert_query="insert into empdata(empname,salary,location) values(?,?,?)";
		
		
		PreparedStatement ptst;
		try {
			ptst = con.prepareStatement(insert_query);
			ptst.setString(1, "anil kumar");
			ptst.setInt(2, 250000);
			ptst.setString(3, "kopparru");
			
			int rows=ptst.executeUpdate();
			
			System.out.println("intrested rows are.."+rows);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			con.close();
		}
		
		
		
	}public void updateemploye() throws SQLException  {
		Connection con=null;
		
		con=JdbcUtil.createConnection();
		
		String update_query="update batch4sql.empdata set empname=? where eid=?";
		
		
		PreparedStatement ptst;
		try {
			ptst = con.prepareStatement(update_query);
			ptst.setString(1, "sai kiran");
			ptst.setInt(2, 2);
			
			int rows=ptst.executeUpdate();
			
			System.out.println("intrested rows are.."+rows);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			con.close();
		}
		
		
		
	}public void deleteemployee() throws SQLException  {
		Connection con=null;
		
		con=JdbcUtil.createConnection();
		
		String delete_query="delete from empdata where eid=?";
		
		
	
		try {
			PreparedStatement	ptst = con.prepareStatement(delete_query);
			ptst.setInt(1, 2);
			
			int rows=ptst.executeUpdate();
			
			System.out.println("intrested rows are.."+rows);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			con.close();
		}
		
		
		
	}public void getbyid() throws SQLException  {
		Connection con=null;
		
		con=JdbcUtil.createConnection();
		
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT * FROM batch4sql.empdata where eid=?");
				
		try {
			
			
               while (rs.next()) {
            	
				
				int eid=rs.getInt(1);
				String empname=rs.getString(2);
				int salary=rs.getInt(3);
				String location=rs.getString(4);
				   PreparedStatement	ptst = con.prepareStatement();
				
				
				System.out.println(" "+eid+"  "+empname+"  "+salary+" "+location);
}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			con.close();
		}
		
		
		
	}
	
	public static void main(String[] args) throws SQLException {
		DynamicOperations dop=new DynamicOperations();
		//dop.saveemployee();
		//dop.updateemploye();
		//dop.deleteemployee();
		dop.getbyid();
		
	}
	
	

}
