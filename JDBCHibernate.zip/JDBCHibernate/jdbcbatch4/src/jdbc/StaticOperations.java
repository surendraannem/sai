package jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StaticOperations {
	
	

public void saveemployee() {
	
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch4sql", "root", "root");
			Statement stmt=con.createStatement();
			int rows=stmt.executeUpdate("update batch4sql.empdata set empname= 'saikiran' where eid=1");
			
			
			System.out.println("interted rows"+rows);
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		 catch (ClassNotFoundException e) {
	
		e.printStackTrace();
	}
	
	
}
public void deleteemployee() {
	
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch4sql", "root", "root");
			Statement stmt=con.createStatement();
			int rows=stmt.executeUpdate("delete from batch4sql.empdata  where eid=1");
			
			
			System.out.println("interted rows"+rows);
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		 catch (ClassNotFoundException e) {
	
		e.printStackTrace();
	}
	
	
}
public void updatemployee() {
	
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch4sql", "root", "root");
			Statement stmt=con.createStatement();
			int rows=stmt.executeUpdate("insert into empdata(empname,salary,location) values('sai',1000000,'guntur')");
			
			
			System.out.println("interted rows"+rows);
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		 catch (ClassNotFoundException e) {
	
		e.printStackTrace();
	}
	
	
}
public void getAllEmployee() {
	
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch4sql", "root", "root");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("SELECT * FROM batch4sql.empdata");
			
			while (rs.next()) {
				
				int eid=rs.getInt(1);
				String empname=rs.getString(2);
				int salary=rs.getInt(3);
				String location=rs.getString(4);
				
				System.out.println(" "+eid+"  "+empname+"  "+salary+" "+location);
				
				
				
			}
			
		} 
		 catch (ClassNotFoundException |SQLException e) {
	
		e.printStackTrace();
	}
	
	
}public void oneEmployee() {
	
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch4sql", "root", "root");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("SELECT * FROM batch4sql.empdata where eid=1");
			
			while (rs.next()) {
				
				int eid=rs.getInt(1);
				String empname=rs.getString(2);
				int salary=rs.getInt(3);
				String location=rs.getString(4);
				
				System.out.println(" "+eid+"  "+empname+"  "+salary+" "+location);
				
				
				
			}
			
		} 
		 catch (ClassNotFoundException |SQLException e) {
	
		e.printStackTrace();
	}
	
	
}



public static void main(String[] args) {
	
	StaticOperations sp=new StaticOperations();
	//sp.saveemployee();
	//sp.updatemployee();
	//sp.deleteemployee();
	//sp.getAllEmployee();
	sp.oneEmployee();
	
}
	

}




