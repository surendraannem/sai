package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcUtil {
	
	
	final static String url="jdbc:mysql://localhost:3306/batch4sql";
	final static String user="root";
	final static String password="root";

	
	public static Connection createConnection() {
		
	Connection con=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection(url, user, password);
	} catch (ClassNotFoundException | SQLException e) {
	
		e.printStackTrace();
	}
		
		return con;
		
	}

}
