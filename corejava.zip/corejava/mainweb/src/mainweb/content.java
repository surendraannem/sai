package mainweb;

public class content {
	public static void main(String[] args) {
		System.out.println("welcome home");
	}

}
