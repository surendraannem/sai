package contructor;

public class Construtor {
	
	public Construtor() {
		
	}
public Construtor(int i) {
		
	}
public Construtor(int i, String name) {
	
}
public static void main(String[] args) {
	Construtor c=new Construtor();
	Construtor c1=new Construtor(10);
	Construtor c2=new Construtor(20, "ajay");
	
}
}
