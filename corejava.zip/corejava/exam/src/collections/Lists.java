package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public class Lists {

public void arraylist() {
	
List<Integer> ar=new CopyOnWriteArrayList<Integer>();
ar.add(10);
ar.add(11);
ar.add(12);
ar.get(2);
//System.out.println(ar.get(2));
ar.remove(1);

for (Integer val : ar) {
	System.out.println(val);
	ar.add(15);
	
}


Iterator<Integer> val=ar.iterator();
while (val.hasNext()) {
	Integer val1 = (Integer) val.next();
	
	System.out.println(val1);
} 

ListIterator<Integer> val2=ar.listIterator();

while (val2.hasNext()) {
	Integer val5 = (Integer) val2.next();
	//System.out.println(val5);
	
}


while (val2.hasPrevious()) {
	Integer val3= (Integer) val2.previous();
	//System.out.println(val3);
	
}
}
public void vectorlist() {
	
	Vector<Integer> v=new CopyOnWriteArrayList<Integer>();
	v.add(1);
	v.add(2);
	v.add(3);
	
	for (Integer val: v) {
		System.out.println(val);
		
		v.add(12);
		
	}
	
	
	
	
	
}









	
	

public static void main(String[] args) {
	Lists l=new Lists();
	//l.arraylist();
	l.vectorlist();
}

	
	
	
}
