package collections;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

public class Sets {
	
	
	public void sets() {
		
	Set<Integer> hs= new CopyOnWriteArraySet <Integer>();
	hs.add(11);
	hs.add(12);
	hs.add(13);
	hs.add(null);
	hs.add(null);
	
	for (Integer val: hs) {
		
		System.out.println(val);
		hs.add(15);
		
	}
	System.out.println(hs);
		
		
	}
	public static void main(String[] args) {
		Sets s=new Sets();
		s.sets();
	}
	
	

}
