package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BirlaProducts implements Comparable<BirlaProducts>{
	
	
	int pid;
	String pname;
	double cost;
	public BirlaProducts(int pid, String pname, double cost) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.cost = cost;
	}
	
	public static void main(String[] args) {
		
		BirlaProducts b=new BirlaProducts(101, "cement", 544.35);
		BirlaProducts b1=new BirlaProducts(108, "sim", 54.03);
		BirlaProducts b3=new BirlaProducts(105, "pantools", 154.04);

	
	List<BirlaProducts> li=new ArrayList<BirlaProducts>();
	li.add(b);
	li.add(b3);
	li.add(b1);
	
	Collections.sort(li);
	
	for (BirlaProducts val: li) {
		
		System.out.println(val);
		
	}
	
		
		
		
		
	}

	@Override
	public String toString() {
		return "BirlaProducts [pid=" + pid + ", pname=" + pname + ", cost=" + cost + "]";
	}

	@Override
	public int compareTo(BirlaProducts o) {
		// TODO Auto-generated method stub
		return this.pname.compareTo(o.pname);
	}
	

	}

