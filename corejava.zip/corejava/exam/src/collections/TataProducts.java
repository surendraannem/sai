package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TataProducts {
	
	int pid;
	String pname;
	double cost;
	public TataProducts(int pid, String pname, double cost) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.cost = cost;
	}
	public static void main(String[] args) {
		
		TataProducts tp=new TataProducts(101, "car", 55000);
		TataProducts tp1=new TataProducts(106, "steel", 500);
		TataProducts tp2=new TataProducts(104, "bike", 1000);
		
		List<TataProducts> li=new ArrayList<TataProducts>();
		li.add(tp2);
		li.add(tp1);
		li.add(tp);
		for (TataProducts val : li) {
			//System.out.println(val);
			
		}
		
		Collections.sort(li, new BasedOnpid());
		
		for (TataProducts val : li) {
			System.out.println(val);
		}
		
		
		
		


		
	}
	@Override
	public String toString() {
		return "TataProducts [pid=" + pid + ", pname=" + pname + ", cost=" + cost + "]";
	}

}
