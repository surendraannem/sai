

package collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Maps {
	
	public void mapinterface() {
		
	Map<Integer, String> mp=new HashMap<Integer, String>();
	
	mp.put(103, "sai");
	mp.put(105,"kiran" );
	mp.put(109, "kopparru");
	
	
	for(Entry<Integer, String> val:mp.entrySet()) {
		System.out.println(val);
	}
	
		
		
	}

}
