package abstarct;

public abstract class Bse {
	
	public abstract void brkeragecharge();


public Bse() {
	
}
static {
	
}


}