package abstarct;

public class Angelgrow extends Bse {

	@Override
	public void brokerCharge() {
		System.out.println("boker caharge is 25/-");
		
	}
	
	public static void main(String[] args) {
		Angelgrow ag=new Angelgrow();
		ag.brokerCharge();
		ag.stockinfo();
	}

}
