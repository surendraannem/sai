package overriding;

public class Class2 {
	
	
private  void bike() {
		
	}
	
public final void car() {
		
	}
	
	public static void land() {
		
	}

}


