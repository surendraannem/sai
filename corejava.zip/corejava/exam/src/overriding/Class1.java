package overriding;

public class Class1 extends Class2 {
	@Override
	public void bike() {
		
	}
	@Override
	public void car() {
		
	}
	@Override
	public void land() {
		
	}

}
