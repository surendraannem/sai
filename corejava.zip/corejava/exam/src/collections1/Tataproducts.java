package collections1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Tataproducts {

	int pid;
	String pname;
	double cost;
	public Tataproducts(int pid, String pname, double cost) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.cost = cost;
	}
	public static void main(String[] args) {
		
		Tataproducts tp= new Tataproducts(101, "cement", 543.23);
		
		Tataproducts tp1= new Tataproducts(105, "sim", 250.52);
		 
		Tataproducts tp2= new Tataproducts(109, "pantanols", 1543.3);

       List<Tataproducts> li=new ArrayList<Tataproducts>();
       
       li.add(tp2);
       li.add(tp1);
       li.add(tp);
       
      // Collections.sort(li,new BasedOnPid());
       
       
       for(Tataproducts val:li) {
    	   System.out.println(val);}
      }
	
	
	
	@Override
	public String toString() {
		return "Tataproducts [pid=" + pid + ", pname=" + pname + ", cost=" + cost + "]";
	}
	
	
}
