package collections1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArraySet;

public class List {
	
	
	public void listmethod() {
		
	ArrayList<Integer> ar=new ArrayList<Integer>();
	ar.add(11);
	ar.add(12);
	ar.add(13);
	
	Collections.sort(ar);
	
	
	//System.out.println(ar.get(2));
	
	for (Integer val : ar) {
		
		//System.out.println(val);
		
	}
	Iterator<Integer> val=ar.iterator();
	while (val.hasNext()) {
		Integer val1 = (Integer) val.next();
		System.out.println(val1);
		
	}
	
	
	}
	public void sets() {
	Set<Integer> se=new CopyOnWriteArraySet<Integer>();
	se.add(14);
	se.add(16);
	se.add(18);
	se.add(19);
	se.add(35);
	
	
	
	for (Integer val: se) {
		//System.out.println(val);
		
		se.add(56);
		
	}
	
Object [] obj=se.toArray();
for (Object val1 : obj) {
	//System.out.println(val1);
	
}
	
	}
	
public static void main(String[] args) {
	List li=new List();
	//li.listmethod();
	li.sets();
	
}
}
