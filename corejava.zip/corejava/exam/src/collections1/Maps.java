package collections1;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class Maps {
	
	
	public void maps() {
		
		Map<Integer, String> mp=new ConcurrentHashMap<Integer, String>();
		mp.put(103, "sai");
		mp.put(105, "kiran");
		mp.put(101, "guntur");
		
		Collections.synchronizedMap(mp);
		
		for(Entry<Integer, String> val:mp.entrySet()) {
			
			System.out.println("..."+val.getKey()+"..."+val.getValue());
			//mp.put(109, "anil");
		}
	
	Iterator<	ConcurrentHashMap.Entry<Integer, String>> val=mp.entrySet().iterator();
	
	while (val.hasNext()) {
		Map.Entry<java.lang.Integer, java.lang.String> val3 = (Map.Entry<java.lang.Integer, java.lang.String>) val
				.next();
		//System.out.println(""+val3.getKey()+"...."+val3.getValue());
	}
		
		
	}
	
	public static void main(String[] args) {
		
		Maps m=new Maps();
		m.maps();
		
	}

}
