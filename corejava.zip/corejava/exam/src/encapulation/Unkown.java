package encapulation;

public class Unkown {
	
	public static void main(String[] args) {
		AccHolder ac=new AccHolder("ajay", 23534, "sbin005", 50000);
		
		System.out.println(ac.accnum);
		System.out.println(ac.name);
		//System.out.println(ac.balance);
		
		ac.setName("sandeep");
		System.out.println(ac.getName());
		
		
	}
}
