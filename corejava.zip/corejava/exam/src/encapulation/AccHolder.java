package encapulation;

public class AccHolder {
	
	
	String name="sai kiran";
	double accnum=23535354;
	String ifsc="sbin005";
	private double balance=434345;
	public AccHolder(String name, double accnum, String ifsc, double balance) {
		super();
		this.name = name;
		this.accnum = accnum;
		this.ifsc = ifsc;
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getAccnum() {
		return accnum;
	}
	public void setAccnum(double accnum) {
		this.accnum = accnum;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
}