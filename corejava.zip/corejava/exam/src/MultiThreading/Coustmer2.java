package MultiThreading;

public class Coustmer2 {
	
	public static void main(String[] args) {
		CustomerWaiting cw=new CustomerWaiting();
		
		new Thread() {
			
			public void run() {
				
			try {
				cw.withdraw(15000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}	
			}
		}.start();
		
		new Thread() {
			
			public void run() {
				cw.dipsite(10000);
				
			}
			
			
		}.start();
   

}
}