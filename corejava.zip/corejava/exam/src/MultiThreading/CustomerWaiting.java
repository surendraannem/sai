package MultiThreading;

public class CustomerWaiting {
	
	int amount=10000;
	
	public synchronized void withdraw(int amount) throws InterruptedException {
		
		System.out.println("coustmer come to with draw.......");
		
		if(this.amount<amount) {
			System.out.println("please wait some time.......");
			wait();
		}
		this.amount=this.amount-amount;
	}
public synchronized void dipsite(int amount) {
	
	System.out.println("coustmer came to dipoaite");
	
	this.amount=this.amount+amount;
	
	notify();
	
	
}
	


}