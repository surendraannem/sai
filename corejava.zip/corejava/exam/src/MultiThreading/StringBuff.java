package MultiThreading;

public class StringBuff {
	
	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("java");
		System.out.println(sb);
		System.out.println(sb.append("..it"));//Used to add text at the end of the existing text.
		System.out.println(sb.insert(8, "...welcome"));// insert values
		System.out.println(sb.delete(3, 7));// dlete values
		System.out.println(sb.reverse());// values revesre
		

		
		
	
	}

}
