package interface1;

public class Redbus implements Phonepay {

	@Override
	public void busbooking() {
		System.out.println("booking sucesfull");
		
	}
	public static void main(String[] args) {
		Redbus r=new Redbus();
		r.busbooking();
	}
	


	

}
