package multi;

public class Swiggy extends Thread{
	@Override
	public synchronized  void  run() {// running
		
		for(int i=0;i<5;i++) {
			System.out.println("thread start is......1"+Thread.currentThread().getName());
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		notifyAll();
	}
	
	
	
	public static void main(String[] args) {
		
		Swiggy s=new Swiggy();
		
		Thread t=new Thread(s);// born
		
		t.start();// runble
		
		Thread t2=new Thread(s);
		t2.start();
		
		
	}
	
	

}
