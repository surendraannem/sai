package multi;

public class Strings {
	
	public static void main(String[] args) {
		
	
	
	String s=new String("sai");
	String s1= "sai";
	String s2=new String("sai");
	String s3=new String("Sai");
	String s4= "kiran";
	String s6= "kiran";

	String s5=new String("kiran");
	System.out.println(s1.equals(s));
	System.out.println(s1==s2);
	System.out.println(s4==s6);
	System.out.println(s1.equals(s3));

	}

}
