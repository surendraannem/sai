package multi;

public class StringTypes {
public static void main(String[] args) {
	
	String s="java";
	String s1="  welcome  Java   ";
	System.out.println(s.concat("  sai it"));//specifed string ends with another string
	System.out.println(s.length());// returns lenghth of the string
	System.out.println(s.charAt(2));// returns charter value of specifed index
	System.out.println(s.compareTo(s1));//both string same returns o value , not same give + or - values 
	System.out.println(s.compareToIgnoreCase(s1));// // it retuns 0 value 
	System.out.println(s.equals(s1));// check two string content equal or not retun true of false
	System.out.println(s==s1);// check object refences like hashcode retun true of false
	System.out.println(s.equalsIgnoreCase(s1));// it retuns true value 
	System.out.println(s.startsWith("j"));// returns string specifed prefix left side
	System.out.println(s.endsWith("v"));// returns string specifed suffix from right  side
	System.out.println(s.indexOf("j"));// retuns the index of string of first occurance
	System.out.println(s.lastIndexOf("v"));//retuns the index of string of last occurance
	System.out.println(s.replace("a", "A"));// replace the characters in string
	System.out.println(s.substring(1));// retuns substing of stiring
	System.out.println(s.substring(1, 3));//retuns substing of stiring middle values 
	System.out.println(s.toUpperCase());// string all characters are convet into upper char
	System.out.println(s.toLowerCase());//string all characters are convet into lower char
	System.out.println(s1.trim());// remove the string before spaces 
     
	
	
}

@Override
public String toString() {
	return "StringTypes [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
			+ "]";
}
}
