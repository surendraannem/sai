package varibles;

public class Typesvaribles {
	
	// instance varibles//primitative data types
	
	//numeric varibles
	byte b=10;
	short s=200;
	int i=2333;
	long l=3400000l;
	
	//decimal varibles
	
	
	double d=2.3;
	float f= 23.45f;
	
	// charter varibles
	
	char c='a';
	
	//boolean types true or false 
	
	boolean kopparruisvillage=true;
	
	//static varibles 
	
	
	static int si=23;
	static double sd=34;
	static char sc='b';
	static boolean gunturIsCity=true;
	
	//wraper or object class varibles
	
	Integer I=10;
	Double D=23.6;
	Character C='C';
	Boolean B=true;
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		
		int j=45;//local varible
		System.out.println(j);
		
		Typesvaribles tv=new Typesvaribles();
		System.out.println(tv.i);
		
		System.out.println(Typesvaribles.si);
		System.out.println(Typesvaribles.gunturIsCity);
		
		
	}
	
	
	

}
