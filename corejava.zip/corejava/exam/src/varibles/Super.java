package varibles;

public class Super {
	int i=10;

}
