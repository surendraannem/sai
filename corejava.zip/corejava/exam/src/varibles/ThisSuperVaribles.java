package varibles;

public class ThisSuperVaribles extends Super {
	
	
	int i=23;
	
	public void cost() {
		int i=32;
		System.out.println(this.i);
		System.out.println(super.i);
	}
	
	public static void main(String[] args) {
		ThisSuperVaribles ts=new ThisSuperVaribles();
		ts.cost();
	}
	
	
	
	
	
	
	
	
	

}
