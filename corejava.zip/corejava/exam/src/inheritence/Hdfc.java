package inheritence;

public class Hdfc extends  Cred {
	@Override
	public void shoppping() {
		
	}
	public void loans() {
		
		
	}
	public void balancecheck() {
		
	}	
	public static void main(String[] args) {
		
		Hdfc h=new Hdfc(); 
		h.cibilscore();
		h.balancecheck();
		
		Cred c1=new Hdfc();
		
		
	}
		
		
	}


