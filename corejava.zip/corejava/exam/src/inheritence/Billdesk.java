package inheritence;

 class Billdesk {
	

	public void loans() {

}
	
	public void billpayment(){
		
	}
	
	
}