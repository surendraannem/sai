package inheritence;

public class Cred {
	
public void shoppping() {
		
	}
	public void loans() {
		
		
	}
	public void cibilscore() {
		
	}	
	public static void main(String[] args) {
		Cred c=new Cred();
		
	}
	
}
