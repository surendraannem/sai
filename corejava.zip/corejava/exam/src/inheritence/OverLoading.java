package inheritence;

public class OverLoading {
	
	public void parachut() {
		
	}
public void parachut(String name,int i) {
		
	}
public void parachut(int i, String name) {
	
	
}
	public static void main(String[] args) {
		OverLoading ov=new OverLoading();
		ov.p
	}

}
