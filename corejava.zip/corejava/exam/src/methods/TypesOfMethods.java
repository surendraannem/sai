package methods;

public class TypesOfMethods {
	
	//instance method 
	
	
	public int i() {
	return 23;
	}
	
	public void product() {
		System.out.println("product value is");
		
		}
	
	//static methods 
	
	public static double d(){
		return 34;
	}
	
	
	public static void main(String[] args) {
		
		TypesOfMethods tp=new TypesOfMethods();
		System.out.println(tp.i());
		System.out.println(TypesOfMethods.d());
		
		
		
	}

}
