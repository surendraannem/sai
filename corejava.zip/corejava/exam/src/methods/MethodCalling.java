package methods;

public class MethodCalling {
	
	
	public void product(int i) {
		
		System.out.println(i);
		
	}
	
	public void productcost(String name, double d, char c) {
		
	}
	
	public static void main(String[] args) {
		
		MethodCalling mc=new MethodCalling();
		mc.product(23);
		mc.productcost("sai", 200.56, 'a');
		
	}
	
	
	

}
