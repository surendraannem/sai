package varibletypes;

public class PrimitiveTypes {
        	
		public static void main(String[] args) {
			short s=20;
			int i=234;
			long l=26244344434434l;
			float f=3.456f;
			double d=3.4756566566565565665;
			System.out.println("sai");
		
		}
}
			
		
		
	
		   

