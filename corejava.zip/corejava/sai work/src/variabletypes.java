
public class variabletypes {

}
