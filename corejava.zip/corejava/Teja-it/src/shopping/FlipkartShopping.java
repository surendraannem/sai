package shopping;

public class FlipkartShopping {
	double totalPrise;
	double totalCost;
	public void invoice() {
		System.out.println("this is flipkart shoppoing ");
		double fashionBill=fashion();
		System.out.println("gst amoount of fashion is 12%");
		System.out.println("this is fashion bill>>>"+fashionBill);
		double mobileBill=mobiles();
		System.out.println("gst amoount of mobiles is 20%");
		System.out.println("this is mobile bill>>>>"+mobileBill);
		double electronicsbill=electronics();
		System.out.println("gst amoount of electroinics is 22%");
		System.out.println("this is electronics bill>>>>"+electronicsbill);
	double finalbill=fashionBill+mobileBill+electronicsbill;
	System.out.println("final bill is "+finalbill);
	System.out.println("------------------------------------");
	System.out.println("thank you visit again");
	
	
	
	}
		
	public double fashion() {
		double shirtPrise=740.34;
		double tShirtPrise=530.34;
		double jeansPrise=799.23;
		double totalPrise=shirtPrise+tShirtPrise+jeansPrise;
		totalCost=gst(totalPrise,Categeris.fashion);
		return totalCost;
	}
	
	public double mobiles() {
		double iPhone=55000;
		double samsung=15000;
		double mi=22000;
		double totalPrise=iPhone+samsung+mi;
		totalCost=gst(totalPrise,Categeris.mobiles);
		
		return totalCost;
	}
	public double electronics() {
		double tv=55000;
		double fridge=15000;
		double laptop=22000;
		double totalPrise=tv+fridge+laptop;
		totalCost=gst(totalPrise,Categeris.electronics);
		
		return totalCost;
		
		
	}
	public double grocery(){
		double atta=12;
		double choclate=15;
		double biscut=22;
		double totalPrise=atta+choclate+biscut;
		totalCost=gst(totalPrise,Categeris.grocery);
		return 0;
	}
	public double gst(double totalPrise, String cat) {
	    double gstAmt;
	    double totalAmtWithGst;
	    if (cat.equals("Fashion")) {
	    	
	    	gstAmt=totalPrise*0.12;
	    	totalAmtWithGst=totalPrise+gstAmt;
	    	return totalAmtWithGst;
	    	
	    }else if (cat.equals("Mobiles")) {
	    	gstAmt=totalPrise*0.22;
	    	totalAmtWithGst=totalPrise+gstAmt;
	    	return totalAmtWithGst;
	    	
	    	
	    }else if(cat.equals("Electronics")) {
	    	gstAmt=totalPrise*0.22;
	    	totalAmtWithGst=totalPrise+gstAmt;
	    	return totalAmtWithGst;
	    	
	    	
	    }else {
	    	gstAmt=totalPrise*0.18;
	    	totalAmtWithGst=totalPrise+gstAmt;
	    	return totalAmtWithGst;
	    	
	    }
		
		
		
	
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		
		FlipkartShopping fs=new FlipkartShopping();
		fs.invoice();
		fs.fashion();
		
		
	}

}
