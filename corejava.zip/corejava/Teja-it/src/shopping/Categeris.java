package shopping;

public class Categeris {
	static String mobiles="Mobiles";
	static String electronics="Electronics";
	static String grocery="Grocery";
	static String fashion="Fashion";
	
	
	
	public static void main(String[] args) {
		System.out.println(Categeris.mobiles);
	}

		
		
	}
	
	


