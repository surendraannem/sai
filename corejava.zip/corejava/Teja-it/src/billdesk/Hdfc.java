package billdesk;

public class Hdfc extends Cred {
	@Override
	
	public void shopping() {
		System.out.println("Hdfc shopping is ");
		
		
	}
	@Override
	public void loans () {
		System.out.println("Hdfc loans is");
		
	}
	public static void main(String[] args) {
		Hdfc h=new Hdfc();
		h.shopping();//hdfc shopping
		h.loans();// hdfc loans
		h.cbilscore();// cred cibil score
		h.billdesk();//bill desk payment
		
		
	}

}
