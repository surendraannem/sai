package billdesk;

public class Billdesk {
	public void billdesk() {
		System.out.println("the payment status is ");
	}
	public static void main(String[] args) {
		Billdesk b=new Billdesk();
		b.billdesk();
		
	}

}
