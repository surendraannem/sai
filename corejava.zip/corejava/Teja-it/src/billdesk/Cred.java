package billdesk;

public class Cred extends Billdesk {
	public void shopping() {
		System.out.println("Cred shopping is ");
		
		
	}
	public void loans () {
		System.out.println("Cred loans is");
	}
	public void cbilscore() {
		System.out.println("cred cbil score is");
	}
	public static void main(String[] args) {
		
	}

}
