package string;

public class Employee {
	
	private final int id;
	private final String name;
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public static void main(String[] args) {
		
		Employee e=new Employee(10, "sai");
		e.name="sai dasari"// immutable
		
		System.out.println(e);
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}
	

}
