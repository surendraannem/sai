package string;

public class StringTypes1 {
	
	public static void main(String[] args) {
		
		String s="Java";
		
		
		System.out.println(s.concat("....oracle"));
		System.out.println(s.charAt(2));
		System.out.println(s.contains("a"));
		System.out.println(s.endsWith("a"));
		System.out.println(s.equals("java"));
		System.out.println(s.equalsIgnoreCase("java"));
		System.out.println(s.hashCode());
		System.out.println(s.indexOf("a"));
		System.out.println(s.isEmpty());
		System.out.println(s.length());
		System.out.println(s.startsWith("J"));
		System.out.println(s.toLowerCase());
		System.out.println(s.toUpperCase());
		int i=10;
		String s1=String.valueOf(i);
		System.out.println(s1);
		
		String s2="sai123";
		
	Integer k=Integer.valueOf(s2);
	//System.out.println(k);
	
		
		
	}

}
