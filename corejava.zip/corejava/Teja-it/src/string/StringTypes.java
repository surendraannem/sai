package string;

public class StringTypes {
	
	
	public static void main(String[] args) {
		
		String s1=new String ("sai");
		String s2="java";
		String s3="sai";
		String s4=new String ("java");
		String s5=new String ("sai");
		String s6="java";
		
		System.out.println(s1==s5);//false
		
		System.out.println(s2==s6);//true
		System.out.println(s2==s4);//false
		System.out.println("======================");
		System.out.println(s1.equals(s5));//true
		System.out.println(s2.equals(s6));
		
		
		
	}

}
