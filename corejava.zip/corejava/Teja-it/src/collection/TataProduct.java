package collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TataProduct {
	
	
	int pid;
	String pname;
	double cost;
	public TataProduct(int pid, String pname, double cost) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.cost = cost;
	}
	
	public static void main(String[] args) {
		
		TataProduct tp=new TataProduct(101, "cement", 500.32);
		TataProduct tp1=new TataProduct(102, "urea", 523.154);
		TataProduct tp2=new TataProduct(104, "car", 50000.12);
		
		List<TataProduct> tata=new ArrayList<TataProduct>();
		
		tata.add(tp2);
		tata.add(tp1);
		tata.add(tp);
		 
		Collections.sort(tata, new BasedOnPid());
	for (TataProduct val : tata) {
		
		System.out.println(val);
		
	}	
	
	
		Collections.sort(tata, new BasedOnPid());
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

	@Override
	public String toString() {
		return "TataProduct [pid=" + pid + ", pname=" + pname + ", cost=" + cost + "]";
	}

}
