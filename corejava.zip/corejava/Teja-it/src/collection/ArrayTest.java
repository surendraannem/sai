package collection;

public class ArrayTest {
	
	
	public static void main(String[] args) {
		
		
		String [] cartitems= {"mi","poco","iphone","real me"};
		
		
		
		
		
		for (int i=3;i>=0;i--) {
			System.out.println(cartitems[i]);
		}
		
		for (String list : cartitems) {
			
		}{
			//System.out.println(list);
		}
		
		
	}

}
