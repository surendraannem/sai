package collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BirlaProduct implements Comparable<BirlaProduct>{

	  
	int pid;
	String pname;
	double cost;
	public BirlaProduct(int pid, String pname, double cost) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.cost = cost;
	}
	
	public static void main(String[] args) {
		
		BirlaProduct BP=new BirlaProduct(101, "jio sim", 34.56);
		BirlaProduct BP1=new BirlaProduct(103, "Airtel sim", 50.56);
		BirlaProduct BP2=new BirlaProduct(105, "voda sim", 150.15);
		BirlaProduct BP3=new BirlaProduct(107, "idea sim", 76.50);
		
		
		List<BirlaProduct> birla=new ArrayList<BirlaProduct>();
		birla.add(BP3);
		birla.add(BP2);
		birla.add(BP1);
		birla.add(BP);
		
	Collections.sort(birla);
		
	for (BirlaProduct val : birla) {
		System.out.println(val);
		
	}	
		
		
		
	}

	@Override
	public String toString() {
		return "BirlaProduct [pid=" + pid + ", pname=" + pname + ", cost=" + cost + "]";
	}

	@Override
	public int compareTo(BirlaProduct o) {
	
		return this.pid-(o.pid);
	}
	
	
}


