package collection;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Stack;
import java.util.Vector;

public class ListTest {
	
	
	public void arrayTest() {
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(12);
		list.add(30);
		list.add(40);
		list.add(50);
         //System.out.println(list.get(2));   //GET VALUE
	for(Integer val:list) {   //for each operATION
		//System.out.println(val);
	}
	
Iterator <Integer> ltr=list.iterator();     //iteration operator
while (ltr.hasNext()) {
	Integer val = (Integer) ltr.next();
	
	//System.out.println(val);
	
}
      ListIterator<Integer> listltr=list.listIterator();   //list iterator operator
      // gives both forword and backword statements
      
      //  *imp* list iterator operator tranverse data form forward to backword
      while (listltr.hasNext()) {
		Integer val = (Integer) listltr.next();
		System.out.println(val);
		
	}
      System.out.println("======================");
      while (listltr.hasPrevious()) {
		Integer  val= (Integer) listltr.previous();
		System.out.println(val);
		
	}
      
      
      
      
      
	}
	

		
	
	public void linkedTest() {
	LinkedList<Integer> li=new LinkedList<Integer>();
		li.add(11);
		li.add(12);
		li.add(13);
		li.add(14);
		li.add(15);
		for(Integer val:li) {
			//System.out.println(val);
		}
		
		ListIterator<Integer> listlt=li.listIterator();
		
		while (listlt.hasNext()) {
			Integer val = (Integer) listlt.next();
			System.out.println(val);
			
		}
		System.out.println("=========");
		while (listlt.hasPrevious()) {
			Integer val = (Integer) listlt.previous();
			System.out.println(val);
			
		}
		
		
		
		
		
		
		
		
	}
	public void vectortest() {
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(11);
		v.add(12);
		v.add(13);
		v.add(14);
		v.add(15);
		for(Integer val:v) {
			//System.out.println(val);
		}
		// elemetens is return ennumeration interface
Enumeration<Integer> ele=v.elements();
		
		while(ele.hasMoreElements()) {
			Integer val=ele.nextElement();
			System.out.println(val);
		}
		
	}	public void stackTest() {
			Stack<Integer> s=new Stack<Integer>();
			
			s.push(12);
			s.push(13);
			s.push(114);
			s.push(15);
			s.pop();
			//System.out.println("====="+s.peek());
			
		for(Integer vol:s) {
			
			
			
			//System.out.println(vol);
			
		}
		
		Enumeration<Integer> ele=s.elements();
				while(ele.hasMoreElements()) {
					Integer val=ele.nextElement();
					System.out.println(val);
				}
		
		
	}
	public static void main(String[] args) {
		ListTest lt=new ListTest();
		 //lt.arrayTest();
		lt.linkedTest();
		//lt.vectortest();
		//lt.stackTest();
	}


}