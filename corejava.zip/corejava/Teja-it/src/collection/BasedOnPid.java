package collection;

import java.util.Comparator;

public class BasedOnPid implements Comparator<TataProduct> {

	@Override
	public int compare(TataProduct o1, TataProduct o2) {
		
		return o1.pid-o2.pid;
	}

}
