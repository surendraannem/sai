package Singleton;

public class Singleton {
	
	private static Singleton Singleton;
	
	private Singleton() {
		
	}
	
	private static Singleton getinstance() {
		
		if(Singleton==null) {
			Singleton =new Singleton();
		}
		
		return Singleton;
	}
	public static void main (String [] args) {
		Singleton s1 =Singleton.getinstance();
		Singleton s2 =Singleton.getinstance();
		Singleton s3 =Singleton.getinstance();
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
	}

}
