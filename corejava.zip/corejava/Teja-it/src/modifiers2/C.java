package modifiers2;

import modifiers1.A;

public class C extends A {
	
	public static void main(String[] args) {
		C c=new C();

		c.test1();
		

	}
}
