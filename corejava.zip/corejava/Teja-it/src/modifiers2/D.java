package modifiers2;

import modifiers1.A;

public class D {public static void main(String[] args) {
	A a=new A();

	a.test1();
	
}

}
