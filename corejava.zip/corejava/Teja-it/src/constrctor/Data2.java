package constrctor;

public class Data2 {
	

	
	
	public Data2(String name) {
	System.out.println(name);
		
	}
	
	public Data2() {
		
	}

	
	
	
	public static void main(String[] args) {
		Data2 D2=new Data2("SAI");
		Data2 D3=new Data2();
		
		
	}

}
