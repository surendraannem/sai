package constrctor;

public class Data {
	

	public Data() {
		System.out.println("data is");
		
	}

	
     public Data(int i) {
    	 System.out.println("data value is ....."+i);
		
	}
     public Data(String name) {
    	 System.out.println("string name is "+name);
 		
	}
	
	public static void main(String[] args) {
		Data d=new Data();
		Data d1=new Data(150);
		Data d2=new Data("SAI");
		
	}

}
