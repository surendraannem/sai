package methos;

public class MerthodsCalling {
	static String cat="mobiles";
	double gst=123;
	public void totalPrise() {
		MerthodsCalling mc1=new MerthodsCalling();
		double gst=123;
		System.out.println("total item and cost prise is>"+mc1.itemAndCost());
         double cost=mc1.itemAndCost();//inii
         System.out.println("cost value"+cost);
		
	}
	public double itemAndCost() {
		double bottlePrise=23.45;
		double pensPrise=45.34;
		double totalPrise=bottlePrise+pensPrise;
		return totalPrise;
	}
	
	public String vendor() {
		return "flipkart";
		
	}

	
	
	
	
	
	
	public static void main(String[] args) {
		MerthodsCalling mc=new MerthodsCalling();
		mc.totalPrise();
	
		System.out.println("vendor name:"+mc.vendor());
		
		
		
	}

}
