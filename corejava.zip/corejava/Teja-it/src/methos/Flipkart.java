package methos;

public class Flipkart {
	public void m1(){
		String [] flipkartCartItems= {"realme","iphone","poco"};
		System.out.println(flipkartCartItems[0]);
		System.out.println(flipkartCartItems[1]);
		System.out.println(flipkartCartItems[2]);
		
	}
	
	public static void main(String[] args) {
		Flipkart fk=new Flipkart();
		fk.m1();
		
	}
	
	
	
}


			
		
		
		
		
		
		


