package methos;

public class Print {
	public static void main(String[] args) {
		int id=20;
		String s="sai";
		System.out.println("id is..."+id+"string name..."+s);
	}

}