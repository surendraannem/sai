package methos;

public class MethodsTest2 {
	public String productName (String name) {
		System.out.println("string name:"+name);
		return "mobile";
		
		}
	public int i() {

	
		return 124;
	}
	
	public void product(String name,int value, String type ) {
		System.out.print("string name"+name+"int value"+value+"string type"+type);
	}
	
 public static void main(String[] args) {
	 MethodsTest2 mt2=new MethodsTest2();
	System.out.println("product name:"+mt2.productName("laptop"));
	mt2.i();
    System.out.println(mt2.i());
    mt2.product("sai",2,"kiran");
  

 }

}
