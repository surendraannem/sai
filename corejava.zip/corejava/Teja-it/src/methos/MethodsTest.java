package methos;

public class MethodsTest {
	
	public int id () {
		System.out.println("this is output");
		System.out.println(MerthodsCalling.cat);
		MerthodsCalling mc3=new MerthodsCalling();
		System.out.println(mc3.cat);
		return 20;
	
	}
    public double d () {
    	return 3.45;
    }
    public char c () {
    	return 'A'; 
    }
    public boolean b () {
    	return true;
    }
    public String s () {
    	return "sai";
    }
	public Integer I() {
		return 123;
	}
	public Float F() {
		return 34.5f;
	}
	public Boolean sai () {
		return true;
	}
	// static method
	
	public static String product() {
		return "mobile";
	}

	
	
	public static void main(String[] args) {
		
	
		MethodsTest m1=new MethodsTest();
		System.out.println("int value is.."+m1.id());
		System.out.println("double value is.."+m1.d());
		System.out.println("char value is.."+m1.c());
		System.out.println("boolean value is.."+m1.b());
		System.out.println("string value is.."+m1.s());
		System.out.println("Integer value is.."+m1.I());
		System.out.println("Float  value is.."+m1.F());
		System.out.println("Boolean  value is.."+m1.sai());
		System.out.println(m1.product());
		
	
	}

}
