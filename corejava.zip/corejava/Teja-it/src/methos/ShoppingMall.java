package methos;

public class ShoppingMall {
	int bill;//
	String cat="electronics";
	String cat1="mobiles";
	String cat2="cloths";
	public void shopping(int amount) {
		if (amount>10000) {
			System.out.println("welcome to cheeni central");
		if (cat1.equals("mobiles")) {
			double bill=5000;
			System.out.println("welcome to mobiles shopping"+bill);
		}else if (cat2.equals("cloths")) {
			bill=2400;
			System.out.println("welcome to cloths ");
		}else if(cat.equals("electronics")) {
			bill=34000;
			int gstamt=123;
			int total=bill+gstamt;
			System.out.println("welcome to elctroniocs..print total:"+total);
		}else {
			System.out.println("thanks for visinting");
		}
		}else {
			System.out.println("no entry insufficient balance");
		}
			
	}
	public static void main(String[] args) {
		
		ShoppingMall sm=new ShoppingMall();
		sm.shopping(500);
		
	}
	

}
