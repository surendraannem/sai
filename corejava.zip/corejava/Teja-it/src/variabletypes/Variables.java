package variabletypes;

public class Variables {
	public static void main(String[] args) {
       int i=10;
       short s=25;
       
       System.out.println("adittion i-s:"+(i-s));
       
	}

}
