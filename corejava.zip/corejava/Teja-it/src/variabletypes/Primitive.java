package variabletypes;

public class Primitive {
	public static void main(String[] args) {
		//numerical data types
		byte b=10;
		short s=223;
		int i=23355;
		long l=23323323323l;
		//decimal data types
		float f=3.53434f;
		double d=34.53434;
		// character data types 
		char c='A';
	
		//objective data types 
		Byte B=10;
		Short S=225;
		Integer I=343434;
		Long L=23323332L;
		System.out.println("adittion b+f:"+(b+f));
	
		
		
	}

}
