package variabletypes;

public class Paytm {
	
	double ticketprise=100;
	
	public void pvr(){
		System.out.println("movie name"+MovieTickets.movieName+"ticket prise"+ticketprise);
	}
	
	public void amb(){
		System.out.println("movie name"+MovieTickets.movieName+"ticket prise"+ticketprise);
	}
	public void imax() {
		double ticketprise=200;
		
		System.out.println("movie name"+MovieTickets.movieName+"ticket prise"+ticketprise);
		
	}
	
	
	
	
	public static void main(String[] args) {
		
		
		Paytm pt=new Paytm();
		pt.amb();
		pt.imax();
		pt.pvr();
		
		
		
	}

}
