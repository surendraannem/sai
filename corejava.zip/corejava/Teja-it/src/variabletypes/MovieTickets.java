package variabletypes;

public class MovieTickets {
	static String movieName="kgf";
}

