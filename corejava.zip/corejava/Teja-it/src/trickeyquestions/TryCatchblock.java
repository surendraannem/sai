package trickeyquestions;

public class TryCatchblock {
	
	public void test1() {
		
		System.out.println("program start is .....");
		int i=10;
		int j=20;
		try{
			int k=j/0;
		
		System.out.println(k);
		}catch (ArithmeticException e) {
		      e.printStackTrace();
		     
		}
		
		finally {
			System.out.println("finally block is............. ");
			
		}
	
		
		System.out.println("program end is.......");
			
		
}
	public static void main(String[] args) {
		
		TryCatchblock tc=new TryCatchblock();
		tc.test1();
	}

}
