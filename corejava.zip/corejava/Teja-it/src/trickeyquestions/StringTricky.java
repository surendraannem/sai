package trickeyquestions;

public class StringTricky {
	
	
	public void test(String str) {
		
		System.out.println("string name is....."+str);
		
	}
	public void test(StringBuilder str) {
		
		System.out.println("string bulder name is..."+str);
		
	}
	public void test(StringBuffer str){
		System.out.println("string buffer name is...."+str);
		
	}
	
	
	public static void main(String[] args) {
		
		StringTricky st=new StringTricky();
		
		//st.test(null); ambiguty issue problem
		st.test("sai");
		StringBuilder sbu=new StringBuilder("kiran");
				st.test(sbu);
				StringBuffer sb=new StringBuffer("dasari");
				st.test(sb);
				
				
		
		
		
		
	}

}
