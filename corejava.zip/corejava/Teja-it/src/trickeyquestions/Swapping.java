package trickeyquestions;

public class Swapping {
	
	public static void main(String[] args) {
		
	
	int i=10;
	int j=20;
	j=j-i;
	i=j+i;
	
	System.out.println("i value is.."+i+"....j value is ...."+j);

}
}