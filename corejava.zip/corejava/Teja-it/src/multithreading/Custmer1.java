package multithreading;

public class Custmer1 {
	
	public static void main(String[] args) {
		CustomerWaiting c=new CustomerWaiting();
		
		new Thread() {
			@Override
		public void run() {
			
			try {
				c.withdraw(15000);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}
			
		}
			
		}.start();
		new Thread() {
			public void run() {
				c.deposit(10000);
				
			}
			
		}.start();
		
		
		}

}
