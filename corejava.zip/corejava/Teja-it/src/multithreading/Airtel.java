package multithreading;

public class Airtel implements Runnable {

	@Override
	public void run() {
		data ();
		
	}
	
	public  static synchronized  void data() {
		
		for( int i=0;i<5;i++) {
			System.out.println("the data is..............."+Thread.currentThread().getName());
			
		}
		
	}
	public static void main(String[] args) {
		
		Airtel a=new Airtel();
		
		Thread t1=new Thread(a);
		t1.start();
		Airtel a1=new Airtel();
		Thread t2=new Thread(a1);
		t2.start();
		
		
		
	}

}
