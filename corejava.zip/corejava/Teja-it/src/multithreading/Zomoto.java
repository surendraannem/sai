package multithreading;

public class Zomoto implements Runnable {

	@Override
	public void run() {// running
		
		for (int i=0;i<10;i++)
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}
		System.out.println("zomoto is..............."+Thread.currentThread().getName());
}
// dead
	
	public static void main(String[] args) {
		
		Zomoto z=new Zomoto();
		
		Thread t1=new Thread(z);// born
		t1.start();// runble
		
		
	}

}
