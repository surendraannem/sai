package multithreading;

public class CustomerWaiting {
	
	int amount=10000;
	
	public synchronized void withdraw (int amount) throws InterruptedException {
		
	System.out.println("customer came to with draw........");	
	
	if(this.amount<amount) {
		
		System.out.println("insuffient funds.....please wait....");
		wait();
	}
	
	
	this.amount=this.amount-amount;
	System.out.println("with draw succefulluy.....");
	
	}
		
	public synchronized void deposit(int amount) {
		
		System.out.println("customer to came to dipost....");
		
		this.amount=this.amount+amount;
		
		System.out.println("diposit scucesfully....");
		
		notify();
	}
	
	
	

}
