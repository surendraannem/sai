package multithreading;

public class Swiggy extends Thread {
	
	@Override
	public synchronized void run() {
		
		for(int i=0;i<5;i++) {
			System.out.println("Run method is...."+Thread.currentThread().getName());
			
		}
		}
	
	public static void main(String[] args) {
		
		Swiggy s=new Swiggy();
		
		Thread t1=new Thread(s);
		
		t1.start();
		
		Thread t2=new Thread(s);
		
		t2.start();
		
		Thread t3=new Thread(s);
		t3.start();
		
		
		
		
	}
	

}
