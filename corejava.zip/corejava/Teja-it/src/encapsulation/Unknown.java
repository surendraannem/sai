package encapsulation;

public class Unknown {
	
	
	
	public static void main(String[] args) {
		
		
		AcctHolderDlts ad1=new AcctHolderDlts("SAI KIRAN",23434,"SBIN003",232423,"ERRORMSG");
		System.out.println(ad1.acctbal);
		System.out.println(ad1.acctnum);
		System.out.println(ad1.holdername);
		
		ad1.setAcctbal(1400000);
		ad1.setHoldername("sai d");
		
	}
	

}
