package encapsulation;

public class Emp2data {
	public static void main(String[] args) {
		
	EmpData ed=new EmpData("sai", "kiran", 337636);
	ed.setEmpid("ed");
	System.out.println(ed.getEmpid());
	}

}
