package encapsulation;

public class EmpData {
	
	private String empname;
	private String empid;
	private double salary;
	public EmpData(String empname, String empid, double salary) {
		super();
		this.empname = empname;
		this.empid = empid;
		this.salary = salary;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	

}
