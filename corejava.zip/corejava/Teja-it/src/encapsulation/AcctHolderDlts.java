package encapsulation;

public class AcctHolderDlts {
	
	String holdername="saik iran";
	int acctnum=292923736;
	String ifsc="sbin000067";
    private int acctbal=23846545;
     String errormsg;
     
     
	
	
	public AcctHolderDlts(String holdername, int acctnum, String ifsc, int acctbal, String errormsg) {
		super();
		this.holdername = holdername;
		this.acctnum = acctnum;
		this.ifsc = ifsc;
		this.acctbal = acctbal;
		this.errormsg = errormsg;
	}
	




	public String getHoldername() {
		return holdername;
	}





	public void setHoldername(String holdername) {
		this.holdername = holdername;
	}





	public int getAcctnum() {
		return acctnum;
	}





	public void setAcctnum(int acctnum) {
		this.acctnum = acctnum;
	}





	public String getIfsc() {
		return ifsc;
	}





	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}





	public int getAcctbal() {
		return acctbal;
	}





	public void setAcctbal(int acctbal) {
		this.acctbal = acctbal;
	}





	public String getErrormsg() {
		return errormsg;
	}





	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}





	public static void main(String[] args) {
		AcctHolderDlts acd=new AcctHolderDlts("SAI KIRAN",23434,"SBIN003",232423,"ERRORMSG");
		System.out.println(acd.holdername);
		System.out.println(acd.acctnum);
		System.out.println(acd.ifsc);
		System.out.println(acd.acctbal);
	}

}
