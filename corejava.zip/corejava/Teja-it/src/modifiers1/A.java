package modifiers1;

 public class A {
	
	
	protected int i=10;
	protected void test1() {
		System.out.println("modifiers test is");
	}
	
	
	
	public static void main(String[] args) {
		A a=new A();

		a.test1();
		
	}

}
