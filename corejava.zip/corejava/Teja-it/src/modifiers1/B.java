package modifiers1;

public class B {
	public static void main(String[] args) {
		A a=new A();

		a.test1();
	}

}
