package clone1;

public class DataCopy implements Cloneable {
	
	int i;
	String name;
	String location;
	
	public static void main(String[] args) throws CloneNotSupportedException {
		DataCopy dc=new DataCopy();
		dc.i=20;
		dc.name="sai kiran";
		dc.location="kopparru";
				System.out.println("value is ..."+dc.i+"..name is .."+dc.name+"..location is..."+dc.location);
	
	
	DataCopy dc1=new DataCopy();
	dc1=(DataCopy) dc.clone();
	
	System.out.println("value is ..."+dc1.i+"..name is .."+dc1.name+"..location is..."+dc1.location);
	
	
	}
	

}
