package clone1;

public class Shaloowcopy {
	int i;
	String name;
	String location;
	
	public static void main(String[] args) throws CloneNotSupportedException {
		DataCopy dc=new DataCopy();
		dc.i=20;
		dc.name="sai kiran";
		dc.location="kopparru";
				System.out.println("value is ..."+dc.i+"..name is .."+dc.name+"..location is..."+dc.location);

				DataCopy dc1=new DataCopy();//varible copy is deep copy
				dc1.i=dc.i;
				dc1.name=dc.name;
				dc1.location=dc.location;
				
				System.out.println("value is ..."+dc1.i+"..name is .."+dc1.name+"..location is..."+dc1.location);
			
				
				
				DataCopy dc2=new DataCopy();
				dc2=dc;// object copy is called shallowcopy
				
				System.out.println("value is ..."+dc2.i+"..name is .."+dc2.name+"..location is..."+dc2.location);

	
	}
}