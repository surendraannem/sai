package variable;

public class A extends B{
	
	int id=20;
	
	public void example() {
		int id =30;
		System.out.println(id);
		System.out.println(this.id);
		System.out.println(super.id);
		
		
		
	}
	public static void main(String[] args) {
		
		A a=new A();
		
		a.example();
		
		
		
	}
	
	
	
	
	
	

}
