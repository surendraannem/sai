package variable;

public class B {

		int id=40;


}
