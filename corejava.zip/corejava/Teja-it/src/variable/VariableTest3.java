package variable;

public class VariableTest3 {
	 String name="sai";//instance variable
	 double d=45.65;
	 static String catagery="mobiles";//static variable
	public static void main(String[] args) {
		
		
		int i=10;//local variable 
		System.out.println(i);
		VariableTest3 v3=new VariableTest3();
		System.out.println(v3.d);
		System.out.println(v3.name);
		System.out.println(VariableTest3.catagery);
		
		
				
		
	}

}
