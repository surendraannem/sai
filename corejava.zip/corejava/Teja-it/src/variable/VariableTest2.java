package variable;
public class VariableTest2 {
	// all number data types default value 0
	//number data types 
	byte id=10;
	short sid;
	int cid;
	long pid;
	//decimal data types(all decimal data types default value 0.0)
	double amount;
	float miles;
	// character data types(default falue space)
	char grade;
	// true or false (default value false)
	boolean isGunturCity;
	// objective or wrapper data types (default value null) 
	String name;
	Integer i;
	Double d;
	Character c;
	Boolean sai;

	
	
		
public static void main(String[] args) {
	VariableTest2 t2=new VariableTest2();//objective creation
	System.out.println(t2.id);
	System.out.println(t2.sid);
	System.out.println(t2.cid);
	System.out.println(t2.pid);
	System.out.println(t2.amount);
	System.out.println(t2.miles);
	System.out.println(t2.isGunturCity);
	System.out.println(t2.name);
	System.out.println(t2.i);
	System.out.println(t2.d);
	System.out.println(t2.c);
	System.out.println(t2.sai);
	
	
	
}
}
