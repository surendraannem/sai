package exception;

public class CustumException {
	
	int bill=10000;
	int balance=2000;
	
	public void balancecheck() {
		if(bill<balance) {
			System.out.println("transition suceeces full");
		}else {
			throw new InsuffientFunds("please add more funds");
		}
		
	}
	public static void main(String[] args) {
		
		CustumException c=new CustumException();
		c.balancecheck();
	}

}
