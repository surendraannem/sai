package exception;

public class Interview {
	
public void questions() {
	
	
	System.out.println("question start is ");
	
	try {int i=10;
	int j=0;
	int k=i/j;
	System.out.println("the value of "+k);
	}catch (ArithmeticException e) {        // sub classs
		e.printStackTrace();
	} catch (NumberFormatException e) {      //sub class
		
		e.printStackTrace();
		
	}catch (Exception e) {                 // super  class
		e.printStackTrace();
	}catch (Throwable e) {                 // super super class
	    e.printStackTrace();
	}
	
System.out.println("question ends.......");

	}
public static void main(String[] args) {
	
	Interview i=new Interview();
	i.questions();
	
	
}
}
