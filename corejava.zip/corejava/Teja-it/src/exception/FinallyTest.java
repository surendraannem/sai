package exception;

public class FinallyTest {
	
	public void testBlock() {
		
		System.out.println("starts with");
		try {int i =10;
		int j=i/0;
		}finally {
		
		System.out.println("msg passsing");
		
		}
		System.out.println("ends with");
		}
	public static void main(String[] args) {
		FinallyTest ft=new FinallyTest();
		ft.testBlock();
	}

}
