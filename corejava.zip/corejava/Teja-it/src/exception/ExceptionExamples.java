package exception;

public class ExceptionExamples {
	
	
	
	public void arthimaticexception() {
		
		System.out.println("arthematic start is.........");
		
		try {int i=10;
		int j=0;
		System.out.println("arthematic value is "+i/j);
		
		}catch (Exception ee){
			
			ee.printStackTrace();
			
		}
		
		
		System.out.println("arthematic end is");
		
		
	}
	
	
	public void arryIndex() {
		try {
	String [] relianceGroup= {"ajio","jio phone","jio sim"};
	
	System.out.println("array index strt is");
	
	System.out.println(relianceGroup[3]);
	
		} catch (ArrayIndexOutOfBoundsException ee) {
			
			ee.printStackTrace();
			
		}
	System.out.println("array index end is");
	
		
		
	}
	
	public void nullpointer() {
		
		System.out.println("null pinter start is");
		
		
		try{ Integer i=null;
		Integer j=30;
		Integer k=i+j;
		
		System.out.println("integer value is"+k);
		}catch (NullPointerException ee) {
			ee.printStackTrace();
		}
		
		System.out.println("null pointer end is");
		
		
		
		
	}
	
	public void numberpoint() {
		
		System.out.println("number format start is");
		
		try {String id="sai123";
		
		Integer empId=Integer.valueOf(id);
		System.out.println("string value is "+empId);
		}catch (NumberFormatException ee) {
		ee.printStackTrace();
		}
		
		System.out.println("number format ends iss.....");
		
		
		
		
		
		
		
	
	}
	
	
	
	
	

	public static void main(String[] args) {

		ExceptionExamples ee=new ExceptionExamples();
		//ee.arthimaticexception();
		//ee.arryIndex();
		//ee.nullpointer();
		ee.numberpoint();
		

	}

}
