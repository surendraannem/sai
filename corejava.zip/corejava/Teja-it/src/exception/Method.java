package exception;

public class Method {
	
	public void m1() {
		
		System.out.println("method 1 is");
		m2();
		
	}
	
	
	public void m2() {
		
		System.out.println("method 2 is ");
		m3();
		
	}
	public void m3() {
		
		System.out.println("method 3 is ");
		m1();
		
	}
	
	
	
	public static void main(String[] args) {
		
		Method m=new Method();
		m.m1();
		m.m2();
		m.m3();
		
		
	}

}
