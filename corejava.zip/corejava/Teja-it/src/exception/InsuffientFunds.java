package exception;

public class InsuffientFunds extends RuntimeException {
	
	public InsuffientFunds(String msg) {
		
		System.out.println(msg);
	
	}


		
	

}
