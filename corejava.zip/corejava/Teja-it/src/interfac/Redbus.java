package interfac;

public class Redbus implements Phonepay{

	@Override
	public void busBokking() {
	int ticketprice=1200;
	System.out.println("ticket price is...... "+ticketprice);
	
	
		
	}
	public static void main(String[] args) {
		Redbus r=new Redbus();
		r.busBokking();
	}
	

}
