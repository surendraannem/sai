package interfac;

public class BlockTesting {
	
	public BlockTesting() {
		System.out.println("constructor");
		
	}
	
	{
		System.out.println("instance block");
	}
	static {
		System.out.println("static block  ");
	}
	public static void main(String[] args) {
		BlockTesting b=new BlockTesting();
		
		
	}

}
