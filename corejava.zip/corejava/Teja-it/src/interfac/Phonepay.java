package interfac;

public interface Phonepay {
	public abstract void busBokking();
	

}
