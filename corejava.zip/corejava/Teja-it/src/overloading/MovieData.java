package overloading;

public class MovieData {
	
	public void movie(int cost, String name) {
		System.out.println("ticket prise is..."+cost+"....movie name is....."+name);
		
		
	}
    public void movie(String name,int cost) {
    	System.out.println("....movie name is....."+name+"....ticket prise is..."+cost);
		
	}
	
	
	
	
	
	
	
	public static void main(String[] args) {
		MovieData m=new MovieData();
		m.movie(150, "gabbarsingh");
		m.movie("sardar", 200);
		
		
	}

}
