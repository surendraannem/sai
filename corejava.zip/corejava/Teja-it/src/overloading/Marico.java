package overloading;

public class Marico {
	
	public void parachute() {
		System.out.println("zero parameter");
		
	}
    public void parachute(int i) {
    	System.out.println("one parameter"+i);
		
	}
     public void parachute(String name, int i) {
    	 System.out.println("two parameter");
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		Marico m=new Marico();
		m.parachute();
		m.parachute(145);
		m.parachute("alovera", 165);
		
	}

}
