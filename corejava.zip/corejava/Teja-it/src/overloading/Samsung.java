package overloading;

public class Samsung {
	
	public void samsung(int i) {
		System.out.println("int method"+i);
		
	}
     public void samsung(String name) {
    	 System.out.println("string method"+name);
		
	}
     public void samsung(boolean itemIsGood) {
    	 System.out.println("boolean method"+itemIsGood);
	
}
	
	
	
	
	
	public static void main(String[] args) {
		Samsung s=new Samsung();
		s.samsung(12000);
		s.samsung("f22");
		s.samsung(true);
				
		
		
	}

}
