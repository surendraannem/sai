package filecreation;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfCreator {
	
	public static void main(String[] args) {
		 {
		      Document document = new Document();
		      PersonalDetailes pd=null;
				BankDetailes bd=null;
				AddressDetailes ad=null;
				
				pd=new PersonalDetailes();
				bd=new BankDetailes();
				ad=new AddressDetailes();
		      
		      
		      
		      try
		      {
		         PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("D:\\Filehandleing\\detailes.pdf"));
		         document.open();
		         document.add(new Paragraph("person detailes .name..."+pd.name+" ..mail id.. "+pd.mailid+"..mbnum...  "+pd.mbnum));
		        
		         document.add(new Paragraph("person adresss.village is."+ad.Village+"..mandal is.. "+ad.mandal+"..dist is..."+ad.dist));
		         
		         document.add(new Paragraph("person bank detailes..acnum.."+bd.accnum+"..ifsc... "+bd.ifsc+"..bal...  "+bd.bal1));
		         document.close();
		         writer.close();
		      } catch (DocumentException e)
		      {
		         e.printStackTrace();
		      } catch (FileNotFoundException e)
		      {
		         e.printStackTrace();
		      }
		   }
		}
	}


