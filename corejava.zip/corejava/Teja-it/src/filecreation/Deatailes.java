package filecreation;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Deatailes {

	public static void main(String[] args) throws IOException {
		
		PersonalDetailes pd=null;
		BankDetailes bd=null;
		AddressDetailes ad=null;
		
		pd=new PersonalDetailes();
		bd=new BankDetailes();
		ad=new AddressDetailes();
		
		System.out.println("person detailes .."+pd.name+"  "+pd.mailid+"  "+pd.mbnum);
		FileWriter fw=new FileWriter("D:\\Filehandleing\\detailes.txt");
	
		BufferedWriter bw=new BufferedWriter(fw);
		bw.write("person detailes .name..."+pd.name+" ..mail id.. "+pd.mailid+"..mbnum...  "+pd.mbnum);
		bw.newLine();
		bw.write("person adresss.village is."+ad.Village+"..mandal is.. "+ad.mandal+"..dist is..."+ad.dist);
		bw.newLine();
		bw.write("person bank detailes..acnum.."+bd.accnum+"..ifsc... "+bd.ifsc+"..bal...  "+bd.bal1);
		bw.close();
	

	}

}
