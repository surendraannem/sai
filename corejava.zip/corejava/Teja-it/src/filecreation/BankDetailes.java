package filecreation;

public class BankDetailes {
	

	String accnum="2035454545";
	String ifsc="sbin002";
	int bal=5500;
	String bal1=String.valueOf(bal);

}
