package filecreation;

public class AddressDetailes {
	
	String Village="kopparru";
	String mandal="pedanandipadu";
	String dist="Guntur";

}
