package filecreation;

public class PersonalDetailes {
	
	String name="sai kiran";
	String mailid="saikopparru@gmail.com";
	String mbnum="98485678";

}
