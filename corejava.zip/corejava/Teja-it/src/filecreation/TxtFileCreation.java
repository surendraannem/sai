package filecreation;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TxtFileCreation {
	public static void main(String[] args) throws IOException {
		
		
		FileWriter fw=new FileWriter("D:\\Filehandleing\\sample.txt.txt");
		BufferedWriter bw =new BufferedWriter(fw);
		System.out.println("program started.....");
		bw.write("sai");
		bw.newLine();
		bw.write("..is from kopparruu");
		System.out.println("pogram completed suceessfully");
		bw.close();
		
	}
	

}
