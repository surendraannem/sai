package hashmap;

import java.util.Comparator;

public class BasedOnCost implements Comparator<Tataproducts> {

	@Override
	public int compare(Tataproducts o1, Tataproducts o2) {
		
		return (int) (o1.cost-o2.cost);
	}

}
