package hashmap;

import java.util.Comparator;

public class BasedOnPname implements Comparator<Tataproducts> {

	@Override
	public int compare(Tataproducts o1, Tataproducts o2) {
	
		return o1.pname.compareTo(o2.pname);
	}

}
