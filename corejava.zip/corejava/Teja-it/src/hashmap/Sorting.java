package hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sorting {
	
	public static void main(String[] args) {
		
		List<Integer> lt=new ArrayList<Integer>();
		lt.add(10);
		lt.add(12);
		lt.add(15);
		lt.add(22);
		lt.add(30);
		//sorting values 
		Collections.sort(lt);
		
		for (Integer val : lt) {
			
			System.out.println(val);
			
			
		}
		
		
		
		
		
	}

}
