package hashmap;

public class HashEquals {

	public static void main(String[] args) {
	// content will same hash will same 
	String name="Sai kiran";
	
	System.out.println(name.hashCode());
	
	
	String name1="Sai kiran";
	System.out.println(name1.hashCode());
	System.out.println(name.equals(name1));
	String name2="Lakshmi";
	System.out.println(name2.hashCode());
	
	String name3="Lakshmi";
	System.out.println(name3.hashCode());
	
	System.out.println(name3.equals(name1));
// content will same equals will give true value
	}

}
