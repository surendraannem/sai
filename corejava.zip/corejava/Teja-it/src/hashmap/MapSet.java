package hashmap;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapSet {

	public static void main(String[] args) {
		
		//super class reference =new sub class object(;)
		Map<Integer, String> map=new HashMap<Integer, String>();
		map.put(121, "sai kiran");
		map.put(122, "gowri shankar");
		map.put(123, "anil kumar");
		
		// for loop will write entry interface and entry set
		for(Entry<Integer, String> data:map.entrySet()) {
			System.out.println(data.getKey()+"   "+data.getValue());
			
			// by call using get key 
		}

	
}
	}

}
