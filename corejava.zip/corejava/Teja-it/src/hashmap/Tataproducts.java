package hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Tataproducts {
	
	int pid;
	String pname;
	double cost;
	
	String filterType="reverse";
	public Tataproducts(int pid, String pname, double cost) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.cost = cost;
	}
	
	public static void main(String[] args) {
		Tataproducts tp1=new Tataproducts(103, "tata salt", 23.54);
		Tataproducts tp2=new Tataproducts(101, "nexon", 5000000);
		Tataproducts tp3=new Tataproducts(103, "tata steel", 534.34);
		Tataproducts tp4=new Tataproducts(103, "tata tea", 50.34);
		
		List<Tataproducts> list=new ArrayList<Tataproducts>();
		list.add(tp1);
		list.add(tp2);
		list.add(tp3);
		list.add(tp4);
		
		Collections.sort(list,new BasedOnPid());
		
		//System.out.println("product id list is..............");
		
		for (Tataproducts tataproducts : list) {
			
			//System.out.println(tataproducts);
			
		}
		//System.out.println("product name list is..............");
		
		Collections.sort(list, new BasedOnPname());
		for (Tataproducts tataproducts : list) {
			
			//System.out.println(tataproducts);
			
		}
//System.out.println("product cost list is..............");
		
		Collections.sort(list, new BasedOnCost());
		String tyep="reverse";
		String cmngValue="normal";
		if(tyep.equals(cmngValue)) {
		Collections.reverse(list);
		}
		for (Tataproducts tataproducts : list) {	
			System.out.println(tataproducts);	
		}
		
}

	@Override
	public String toString() {
		return "Tataproducts [pid=" + pid + ", pname=" + pname + ", cost=" + cost + "]";
	}
	

}
