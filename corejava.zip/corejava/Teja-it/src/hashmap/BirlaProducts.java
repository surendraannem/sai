package hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BirlaProducts implements Comparable<BirlaProducts> {
	
	int pid;// declare data
	String name;
	double cost;  // soure to write constructor
	public BirlaProducts(int pid, String name, double cost) {
		super();
		this.pid = pid;
		this.name = name;
		this.cost = cost;
	}
	public static void main(String[] args) {
		
		BirlaProducts bp1= new BirlaProducts(101, "birlawhite", 45.56);
		BirlaProducts bp2= new BirlaProducts(103, "utratech", 450.54);
		BirlaProducts bp3= new BirlaProducts(102, "birlsoft", 145.46);
		BirlaProducts bp4= new BirlaProducts(104, "idea sim", 200.56);
		
		List<BirlaProducts> list=new ArrayList<BirlaProducts>();
		
		list.add(bp1);
		list.add(bp2);
		list.add(bp3);
		list.add(bp4);
		
		Collections.sort(list);
		//step1. brirla product implemtes t0 comparable 
		for (BirlaProducts birla : list) {
			System.out.println(birla);
			
		}
		
		
			}
	
			/*
			 * @Override public int compareTo(BirlaProducts o) {
			 * 
			 * return this.pid-o.pid; }
			 */
// compare to stringb  	
	@Override
	public int compareTo(BirlaProducts o) {
	
		return this.name.compareTo(o.name);
	}
	
	
	// soure to use string to 
	@Override
	public String toString() {
		return "BirlaProducts [pid=" + pid + ", name=" + name + ", cost=" + cost + "]";
	}
	
	
	

}
