package hashmap;


import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public class Cocurentset {
public static void main1(String[] args) {
	
	List<Integer> list=new CopyOnWriteArrayList<Integer>();
	list.add(10);
	list.add(12);
	
	for (Integer val1 : list) {
		
		//System.out.println(val1);
		
		list.add(13);
		
	}
	//System.out.println(list);
	
	
	
}

public static void main(String[] args) {
	
	Set<Integer> set=new CopyOnWriteArraySet<Integer>();
	set.add(6);
	set.add(7);
	
	for (Integer val2 : set) {
		
		System.out.println(val2);
		set.add(8);
		
	}
	System.out.println(set);
	
	
	
	
}
	
	public static void main2(String[] args) {
		
		Map<String, String> map=new ConcurrentHashMap<String, String>();
		
		map.put("A", "sai");
		map.put("B", "kiran");
		map.put("c", "dasari");
		
		for (Entry<String, String> val : map.entrySet() ) {
			
			//System.out.println(val.getKey()+"   "+val.getValue());
			map.put("D", "KOPPARRU");
			
		}
		
		
		
		
		
	}

}
