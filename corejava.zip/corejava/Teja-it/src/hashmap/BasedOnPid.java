package hashmap;

import java.util.Comparator;

public class BasedOnPid implements Comparator<Tataproducts> {

	@Override
	public int compare(Tataproducts o1, Tataproducts o2) {
		
		return o1.pid-o2.pid;
	}

}
