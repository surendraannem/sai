package loops;

public class AllLoops {
	
	
	public static void main(String[] args) {
		//for loop
		for(int i=0;i<10;i++) {
			//System.out.println(i);
			
		}
		//foreach
		String [] items= {"sai","kiran"};
		
		for (String name: items) {
			System.out.println(name);
			
		}
		
		
		//whileloop
		
	int j=1;
	while(j<10){
		//System.out.println(j);
		j++;
	}
	//do-while
	
	int k=0;
	do {
		//System.out.println(k);
		k++;
		
	} while (k<10);
		
		
		
		
	}


}
