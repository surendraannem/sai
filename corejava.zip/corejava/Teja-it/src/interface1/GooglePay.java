package interface1;

public interface GooglePay {

}
