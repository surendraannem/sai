package interface1;

public interface Phonepay {
	
	 void busbooking();

}
