package interface1;

public class Redbus implements Phonepay {
	
		@Override
	public void busbooking() {
			
			int tiketprsise=100;
			int gst=22;
			int totalprise=tiketprsise+gst;
			System.out.println("ticket prise is"+totalprise);
		
		
	}
		public static void main(String[] args) {
			
			Redbus r=new Redbus();
			r.busbooking();
		}

}
