package abstarct;

public abstract  class Bse {
	
	
	public abstract void  brakerage();{
		
	}
	
	
	public void stackInfo(){
		System.out.println("hdfc......icici.....relianace.....adani");
	}
	{
		System.out.println("Bse intance block");
	}
	static {
		System.out.println("Bse static block");
	}
	
	public Bse() {
		System.out.println("bse constrctor block is");
	}

}
