package abstarct;

public class UpStock extends Bse {

	@Override
	public void brakerage() {
		System.out.println("bokerage charge is 20/-");
		
		
	}
	public static void main(String[] args) {
		
		UpStock u=new UpStock();
		u.brakerage();
		u.stackInfo();
		
		
		
		
	}
	
	

}
