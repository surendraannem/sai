package oops;

public class Parent extends GrandParent {
	
	
	public void bike() {
		System.out.println("parent bike is");
		
	}
	public void car() {
		System.out.println("parent car is");
		
	}
	
	public static void main(String[] args) {
		Parent p=new Parent();
		p.bike();
		p.car();
		
		
	}

}
