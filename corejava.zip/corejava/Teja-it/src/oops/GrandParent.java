package oops;

public class GrandParent {
	
	public void gold(){
		System.out.println("grand parent gold is ");
		
	}
	public void cycle() {
		System.out.println("grand parent cycle is");
		
	}
	public static void main(String[] args) {
		GrandParent gp=new GrandParent();
		gp.gold();
		gp.cycle();
		
		
	}

}
