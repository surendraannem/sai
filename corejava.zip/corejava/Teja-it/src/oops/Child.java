package oops;

public class Child extends Parent {
	@Override
	
	public void bike() {
		System.out.println("child bike is ");
		
	}
	
	
	
	public static void main(String[] args) {
		
		Child c= new Child();
		c.bike();//chlid bike
		c.car();// parent car
		c.gold();// grand parent gold
		c.cycle();// grand poarent cycle
		Parent  p= new Parent();
		c.bike();
		c.car();
		
		
	}

}
