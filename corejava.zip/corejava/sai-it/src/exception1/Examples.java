package exception1;

public class Examples {
	
	
	public void arthematicException1() {
		
		try {int i=10;
		int j=10/0;
		System.out.println("the value of j is"+j);
		}catch (ArithmeticException e) {
			e.printStackTrace();
		}finally {
			System.out.println("some error appaear");
		}
		
		
	}
	public static void main(String[] args) {
		
		Examples ex=new Examples();
		ex.arthematicException1();
		
	}

}
