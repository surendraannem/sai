package ownpractice;

public class Moviecat {
 static String movie="kgf2";
}
