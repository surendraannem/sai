package ownpractice;

public class MethodCalling1 {
	
	int totalcost;
	
	
	public int shop() {
		int oil=23;
		int shpooo=4;
		int coconut=24;
		int recharge=23333;
		totalcost=oil+shpooo+coconut+recharge;
		int totalprise=gst(totalcost);
		System.out.println("total prise is"+totalprise);
		return totalprise; 
	
	}
	public  int gst(int totalcost) {
		
		int gst=22;
		int gstamtwithtotalcost=22+totalcost;
		
	
		
		return gstamtwithtotalcost ;
	}
	
	
	
	
	
	public static void main(String[] args) {
		MethodCalling1 m1=new MethodCalling1();
		m1.shop();
	
		
		
	}

}
