package ownpractice;

public class MoviePrise {
	
	double ticketprise=234;
	public void pvr(){
		
		System.out.println("movie name is"+Moviecat.movie+"prise is "+ticketprise);
		
	}
	
	public void pvp() {
		
	}
	
	
	public void kvp(){
		
	}
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		MoviePrise mp=new MoviePrise();
		mp.pvp();
		mp.pvr();
		mp.kvp();
		
		
	}

}
