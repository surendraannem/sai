package ownpractice;

public class Vari {
	
	
		 int i=28;
		

}
