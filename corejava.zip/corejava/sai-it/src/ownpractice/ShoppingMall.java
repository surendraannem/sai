package ownpractice;

public class ShoppingMall { 
	static String cat1="mobiles";
	static String cat2="electronics";
	
	public void shoppingmal(int amount) {
		
		if(amount>1000){
			System.out.println("welcome to shopping mall");
			
		}else if(cat1.equals("Mobiles")) {
			System.out.println();
		}else {
			System.out.println("thanks for visiting");
		}
			
		
			
		}
		
	
	
	
	
	
		public static void main(String[] args) {
			ShoppingMall sm=new ShoppingMall();
			sm.shoppingmal(235);
			

}
}