package ownpractice;

public class VaribleTypes extends Vari {
	 int i=10;
	static String S1="sai";
	
	public void product() {
		int i=23;
		
		System.out.println(this.i);
		System.out.println(super.i);
	
		
	}
	
	public static void main(String[] args) {
		
		
		VaribleTypes v=new VaribleTypes();
		//System.out.println(v.i);
		//System.out.println(VaribleTypes.S1);
		v.product();		
		
	}

	}
	
	
	
		
		
		
	


