package ownpractice;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Vector;

public class Collections {
	
	public void arraylist() {
		ArrayList<Integer> ar=new ArrayList<Integer>();
		ar.add(12);
		ar.add(14);
		ar.add(15);
		ar.add(16);
		//System.out.println("get varible is "+ar.get(1));
		
		for (Integer val : ar) {
			
			//System.out.println(val);
			
			
		}
		                  ListIterator<Integer>ar1 =ar.listIterator();
		                  
		                 while (ar1.hasNext()) {
							Integer val= (Integer) ar1.next();
							
							//System.out.println(val);
							
						} 
		                 
		                 System.out.println("========");
		                 while (ar1.hasPrevious()) {
							Integer val = (Integer) ar1.previous();
							
							//System.out.println(val);
							
						}
		                  
		      
					
				}  
	public void vectorlist() {
		Vector<Integer> v1=new Vector<Integer>();
		
		
		v1.add(12);
		v1.add(14);
		v1.add(15);
		v1.add(16);
		
		
		Enumeration<Integer> v2=v1.elements();
		
	while (v2.hasMoreElements()) {
		Integer val = (Integer) v2.nextElement();
		
		System.out.println(val);
		
	}
			
		}
			
		
		
		
		
		
		
		
		
		
	
		          
		          
		          
		          
		          
		                   
		
	
	public void linkedlist() {
		LinkedList<Integer> li=new 	LinkedList<Integer> ();
		li.add(2);
		for (Integer val : li) {
			
		}
		
	}
	
	
	
	public static void main(String[] args) {
		
		Collections c=new Collections();
		//c.arraylist();
		c.vectorlist();
		
		
		
		
		
	}
	

}
