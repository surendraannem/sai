package ownpractice;

public class Methodtypes {
	
	
	public int i() {
	
		return 23;
		
	}
	public static double d() {
		return 234;
	}
	public void product(int i) {
		System.out.println(i);
		
	}
	
	
	
	public static void main(String[] args) {
		Methodtypes m=new Methodtypes();
		System.out.println(m.i());
		System.out.println(m.d());
		m.product(224);
		
		
		
		
	}
	
}


