package over;

final class Overridding2 {
    public void m1() {
		
	}
	
	public void m2() {
		
	}   
}
