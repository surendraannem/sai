package over;

public class OverLodding {
	
	
	
	public void parachute(int cost, String smell) {
		
	}
public void parachute(String smell, int cost) {
		
	}

}
