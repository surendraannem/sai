package over;

public class Overridding1 extends Overridding2 {
	@Override
	public void m1() {
		
	}
	@Override
	public void m2() {
		
	}

}
