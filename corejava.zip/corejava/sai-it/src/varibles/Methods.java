package varibles;

public class Methods {
	
	
	public int i() {
		return 234;
	}
	
	public static int id() {
		return 56;
	}
	
	public void cost(int iS) {
		String s="sai";
		char c='a';
		double d=23.6;
		System.out.println(s);
		System.out.println(iS);
	}
	

		
		
	public static void main(String[] args) {
		
		Methods m1=new Methods();
		System.out.println(m1.i());
		System.out.println(Methods.id());
		m1.cost(56);
		
		
		
	}	
		
		
		
	

}
