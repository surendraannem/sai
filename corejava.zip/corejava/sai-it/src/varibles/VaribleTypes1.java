package varibles;

public class VaribleTypes1 {
	
	int i;
	int id=23999999;
	double d=24.2;
	char c='a';
	String s="sai";
	public void cost() {
		int i;
		int id=235;
		double d=24.2;
		char c='a';
		String s="sai";
		System.out.println(this.i);
	}
	
	
	
	public static void product() {
		
		int id=232;
		double d=24.2;
		char c='a';
		String s="sai";
		System.out.println(id);
		
	}
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		
		VaribleTypes1 v1=new VaribleTypes1();
		System.out.println(v1.i);
		System.out.println(v1.id);
		
		VaribleTypes1.product();
		v1.cost();
		
	}

}
