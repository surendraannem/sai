package abtract;

public abstract class Nse {
	
public abstract void brokerage();

public void stockinfo() {
	System.out.println("today market start with profits more");
}
{
	System.out.println("after noon low");
	
}static{
	System.out.println("evng market is low");
	
}
public Nse() {
	System.out.println("final report is");
}

}
