package abtract;

public class Angelone extends Nse {

	@Override
	public void brokerage() {
	
		
	}
	public void charges() {
		System.out.println("for transion charge is 20/-");
	}
	public static void main(String[] args) {
		Angelone a=new Angelone();
		a.brokerage();
		a.stockinfo();
		a.charges();
	}

}
