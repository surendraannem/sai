package map1;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Hashmap1 {

	public static void main(String[] args) {
		
		Map<Integer, String> map=new HashMap<Integer, String>();
		
		map.put(106,"welcome to");
		map.put(104, "teja ");
		map.put(108, "it");
		
		
		for(Entry<Integer, String> data :map.entrySet()) {
			System.out.println(data.getKey()+"   "+data.getValue());
			
		} 
			
		}
		
		
		
		
		
		
	}
	
	

