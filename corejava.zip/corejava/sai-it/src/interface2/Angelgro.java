package interface2;

public class Angelgro implements Bse,Nse{

}
