package interface2;

public interface Bse {

}
