package inheritence1;

public class Hdfc {
	
	public void shopping() {
		System.out.println("Hdfc shopping is ");
	}
	
	
	public void loand
	
	
	
	

	public static void main(String[] args) {
		
		
	}

}
