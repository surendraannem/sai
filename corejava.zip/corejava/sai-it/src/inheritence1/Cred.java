package inheritence1;

public class Cred {

}
