package abstarct1;

public class BuseLink {

}
