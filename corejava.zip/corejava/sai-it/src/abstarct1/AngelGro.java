package abstarct1;

public class AngelGro extends Bse {

	@Override
	public void brokerage() {
		System.out.println("the brokerage fee is 20/-");
		
	}
	public static void main(String[] args) {
		
		AngelGro ag=new AngelGro();
		ag.brokerage();
		ag.stockinfo();
	}

}
