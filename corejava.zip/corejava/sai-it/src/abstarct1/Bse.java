package abstarct1;

public abstract class Bse {
	
	
	public abstract void brokerage();
	public  void stockinfo() {
		System.out.println("the stock ino aitel, jio");
		
		
	}

	}
	
	
	


