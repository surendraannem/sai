package amazon;

public class AmazonShopping {
	
	double cost;
	double finalprise;
	
	public void invoice() {
		
		double m=mobiles();
		System.out.println(m);
		double e=electronics();
		System.out.println(e);
		double g=grcocery();
		System.out.println(g);
		
	}
	
	public double mobiles() {
		
		double poco=23000;
		double mi=50000;
		double vivo=12000;
		double cost=poco+mi+vivo;
		finalprise=gst(cost,Categiries.mobiles);
				return finalprise;
	}
public double electronics() {
		
		double tv=2300;
		double fridge=5000;
		double wmachine=1200;
		double cost=tv+fridge+wmachine;
		finalprise=gst(cost,Categiries.electronics);
		return finalprise;
	}
public double grcocery() {
	
	double atta=23;
	double biscut=50;
	double choc=12;
	double cost=atta+biscut+choc;
	
	finalprise=gst(cost,Categiries.grocery);
	return finalprise;
}
public double gst(double cost, String Categiries) {
	
	double gst;
	double gstwithfinalprise;
	
	if(Categiries.equals("Mobiles")) {
		
		gst=cost*0.22;
		gstwithfinalprise=gst+cost;
		
		return gstwithfinalprise;
		
		
	}else if(Categiries.equals("Electronics")) {
		
		gst=cost*0.18;
		gstwithfinalprise=gst+cost;
		
		return gstwithfinalprise;
	
	}else {
		
		gst=cost*0.15;
		gstwithfinalprise=gst+cost;
		
		return gstwithfinalprise;
	
	}
	
}



public static void main(String[] args) {
	AmazonShopping am=new AmazonShopping();
	am.invoice();
}
}
