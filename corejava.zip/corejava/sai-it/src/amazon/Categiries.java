package amazon;

public class Categiries {
	
	static String mobiles="Mobiles";
	static String electronics="Electronics";
	static String grocery="Grocery";
	
	

}
