package amazon;

public class Arthematic {
	
	public  void arthematic() {
		System.out.println("program start is");
		int i=9;
		int j=5;
		try{
			int k=j/0;
		
		System.out.println(k);}catch (ArithmeticException e) {
			
		}
		System.out.println("program end is");
	
		
	}
	public static void main(String[] args) {
		
		Arthematic a=new Arthematic();
		a.arthematic();
	}

}
