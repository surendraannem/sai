package amazon;

public class Thrownew {
	
	int bill=1000;
	int balance=200;
	public void shoppping() {
		
		if(bill<balance) {
			System.out.println("thank shopping");
		}else {
			throw new Insuffentfunds("add more balance");
		}
	}
	
	public static void main(String[] args) {
		
		Thrownew t=new Thrownew();
		t.shoppping();
	}

}
