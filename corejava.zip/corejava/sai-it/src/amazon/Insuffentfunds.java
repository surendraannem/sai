package amazon;

public class Insuffentfunds extends RuntimeException {
	
	public Insuffentfunds(String msg) {
		System.out.println(msg);
		
	}
	

}
