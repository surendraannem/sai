import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CoconutOil implements Comparable<CoconutOil> {
	int pid;
	String name;
	double cost;
	public CoconutOil(int pid, String name, double cost) {
		super();
		this.pid = pid;
		this.name = name;
		this.cost = cost;
	}
	public static void main(String[] args) {
		CoconutOil c1=new CoconutOil(101, "parachute", 34.56);
		CoconutOil c2=new CoconutOil(103, "jasme", 55.34);
		CoconutOil c3=new CoconutOil(102, "dobur", 70.56);
		
		List<CoconutOil> list=new ArrayList<CoconutOil>();
		list.add(c1);
		list.add(c2);
		list.add(c3);
		
		Collections.sort(list);
		
		
		
	}
	@Override
	public int compareTo(CoconutOil o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
