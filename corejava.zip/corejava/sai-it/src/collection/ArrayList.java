package collection;

public class ArrayList {
	
public void arraylist() {
	
	
	
	
	
	
}

}
