package inhertence1;

public class Hdfc extends Cred {
	
	@Override
	
	public void shopping() {
		System.out.println("Hdfc shopping is ");
		
		
	}
	@Override
	public void loans() {
		System.out.println("hdfc loan is");
		
	}
	public void account() {
		
	}
	
	public static void main(String[] args) {
		Hdfc h=new Hdfc();
		h.shopping();
		h.loans();
		h.cibilscore();
		
Cred c1=new Hdfc();
c1.shopping();
c1.loans();
c1.account();

	}

}
