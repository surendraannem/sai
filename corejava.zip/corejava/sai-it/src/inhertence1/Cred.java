package inhertence1;

public class Cred {
	
public void shopping() {
	
		
		
	}
	public void loans() {
		
	}
	
	
	public void cibilscore() {
		
		System.out.println("cred cibil score");
		
	}
	public static void main(String[] args) {
		
		
	}

}
