package methodcalling;

public class Flipkart {
	
	double totalprise;
	double totalcost;
	
	public void invoice() {
		
	double fashion=fashion();
	System.out.println("fashion bill is"+fashion);
	double grocery=grocery();
	
		System.out.println(grocery);
	}
	
	public double fashion() {
		double shirt=200;
		double jeans =300;
		double tshirt=200;
		totalprise=shirt+jeans+tshirt;
		
		totalcost=gst(totalprise,Categeries.fashion);
		return totalcost; 
		
	}
	
	public double electronics() {
		double tv=2000;
		double fridge =3000;
		double machine=1200;
		totalprise=tv+fridge+machine;
		totalcost=gst(totalprise, Categeries.electronics);
		return totalcost;
	}
	public double grocery() {
		double biscut=20;
		double choc =30;
		double icecream=12;
	
		totalprise=biscut+choc+icecream;
		totalcost=gst(totalprise, Categeries.grocery);
		
	
	
		return totalcost;
}
	
	public double gst(double totalprise,String Categeries) {
		double gst;
		double gstwithamt;
		
		
		if(Categeries.equals("Fashion")) {
			gst=totalprise*0.22;
			gstwithamt=totalprise+gst;
			return gstwithamt;
			
			
		}else if(Categeries.equals("Electronics")) {
			
			gst=totalprise*0.20;
			gstwithamt=totalprise+gst;
			return gstwithamt;
			
		}else{
			gst=totalprise*0.18;
			gstwithamt=totalprise+gst;
			return gstwithamt;
			
		}
		
		
		

	}
	
	
	
	public static void main(String[] args) {
		
		Flipkart ft=new Flipkart();
		ft.invoice();
		
	}
	
	
	
}