package methodcalling;

public class ShoppingMall {
	
	
	int bill;
	
	String mobiles="mobiles";
	String ele="electronics";
	
	
	public void shopping(int amount) {
		
		if(amount>1000) {
			System.out.println("welcome to shopping mall");
		} if(mobiles.equals(mobiles)){
			
			
			
		}else if(ele.equals("electronics")) {
			
		}else  {
			
			System.out.println("insufficent balance");
			
		}
		
		
		
	}
	public static void main(String[] args) {
		
		ShoppingMall sm=new ShoppingMall();
		sm.shopping(2000);
	}

}
