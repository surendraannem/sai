package methodcalling;

public class Categeries {

	static String fashion="Fashion";
	static String electronics="Electronics";
	static String home="Home";
	static String grocery="Grocery";
	
	
	
	
}
