package methodcalling;

public class Methodcalling {
	double totalprise;
	double totalcost;
	
	public double fashion() {
		double jeans=150;
		double shirt =100;
		double tshirt=200;
		
		totalprise=jeans+shirt+ tshirt;
		
		totalcost=gst(totalprise);
		System.out.println(totalcost);
		
		return totalcost;
		
	}
	
	public double gst(double totalprise) {
		
		double gst=22;
		double gstwithtotalprise=gst+totalprise;
	
	return gstwithtotalprise;

}
	public static void main(String[] args) {
		Methodcalling m=new Methodcalling();
		m.fashion();
		
		
	}
	
}
