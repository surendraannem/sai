package swithcase;

public class SwithLoops1 {
	
	public static void main(String[] args) {
		
		int i=10;
		switch (i) {
		case 9:
			System.out.println("print value ok..9.."+i);
			break;
case 12:
	System.out.println("print value ok...12..."+i);
			break;
case 10:
	System.out.println("print value ok....10..."+i);
	break;

		default:
			System.out.println("print deauflt value......");
			break;
		}
	}
}
