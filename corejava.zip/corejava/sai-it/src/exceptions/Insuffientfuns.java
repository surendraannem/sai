package exceptions;

public class Insuffientfuns extends RuntimeException {
	
	public Insuffientfuns(String msg) {
		System.out.println(msg);
		
	}

}
