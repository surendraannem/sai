package exceptions;

public class Thowex {
	
	int bill=10000;
	int balance=1000;
	
	public void shopping() {
		if(bill<balance) {
			System.out.println("transition sucessful");
		}else {
			throw new Insuffientfuns("add balance amount");
		}
			
	}
	public static void main(String[] args) {
		
		Thowex t=new Thowex();
		t.shopping();
	}

}
