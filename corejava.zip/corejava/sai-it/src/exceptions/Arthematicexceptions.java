package exceptions;

public class Arthematicexceptions {
	
	
	public void values() {
		
		System.out.println("program start is");
	try{ 
		int i=20;
	int j=25;
	int k=j/0;
	System.out.println(i);
	System.out.println(k);
	}catch (ArithmeticException e) {
		e.printStackTrace();
	}
	System.out.println("program end is");
	
	}
	
	public void arrayoutbox() {
		System.out.println("program start is");
		
		String [] collections= {"sai","kiran","dasari"};
		
		System.out.println(collections[1]);
		try{
			System.out.println(collections[5]);
		}catch (ArrayIndexOutOfBoundsException ee) {
			ee.printStackTrace();
		}
				System.out.println("program end is");
		}
		
		
		
		
	
	
	
	
	
	public static void main(String[] args) {
		
		Arthematicexceptions ae=new Arthematicexceptions();
		//ae.values();
		ae.arrayoutbox();
		
	}

}
