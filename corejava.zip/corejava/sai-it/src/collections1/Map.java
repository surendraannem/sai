package collections1;

public class Map {
	Map<Integer,String>map=new HashMap<Integer, String>();

	map.put(109, "Prashanth");
	map.put(106, "shareef");
	map.put(110, "Subhani");
	map.put(104, "sai");

	for(Entry<Integer, String>data:map.entrySet()){
	System.out.println(data.getKey()+" "+data.getValue());

	}
	}
}
