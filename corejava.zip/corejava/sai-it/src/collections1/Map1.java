package collections1;

import java.security.DomainCombiner;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Map1 {
	
	
	public  void map2() {
		
		Map<Integer, String> m=new LinkedHashMap<Integer, String>();
		
		m.put(101, "guntur");
		m.put(104, "is a");
		m.put(102, "city");
		
		for(Entry<Integer, String>data:m.entrySet()) {
			
			System.out.println(data.getKey()+" ......   "+data.getValue());
			
		}
		
		
		
	}
public static void main(String[] args) {
	
	Map1 m2=new Map1();
	m2.map2();
	
}
}
