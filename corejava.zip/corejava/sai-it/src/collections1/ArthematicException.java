package collections1;

import exceptions.Arthematicexceptions;

public class ArthematicException {
	
	public void arthematicexception() {
		System.out.println("program start is");
		int i=10;
		int j=20;
		try {int k=j/0;
				
	System.out.println(k);	}
		catch (ArithmeticException moji) {
		moji.printStackTrace();
			
		}
		System.out.println("program end is");
		
	}
	
	
	public void arrayindex() {
		
		System.out.println("program start is");
		
		String [] cartitems= {"guntur","vij","sateenapalli"};
		
		try{System.out.println(cartitems[3]);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			
		}
		System.out.println("program end is");
	}
	public void nullponter() {
		System.out.println("program start is............");
		int i=10;
		Integer j=null;
		try {int k=i+j;
		System.out.println(k);}
		catch (NullPointerException e) {
		
		}
		System.out.println("program end is");
	}public void numberformat() {
		System.out.println("program start is............");
		String id="ajay";
	try {	Integer i=Integer.valueOf(id);

	System.out.println(i);
	
	}catch (NumberFormatException e) {
	
	}
	
		System.out.println("program end is");
		
	}
	
	public static void main(String[] args) {
		
		ArthematicException ae=new ArthematicException();
		ae.arthematicexception();
		//ae.arrayindex();
		//ae.nullponter();
		//ae.numberformat();
		
	}
	
	

}
