package collections1;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

public class List11 {
	
	public void arraylist() {
	
	List<Integer> list=new ArrayList<Integer>();
	
	list.add(10);
	list.add(11);
	list.add(12);
	list.add(0, 50);
	list.remove(1);
	
	for (Integer val : list) {
		System.out.println(val);
		
	}
	
	Iterator<Integer> data=list.iterator();
	
	while (data.hasNext()) {
		Integer val = (Integer) data.next();
		//System.out.println(val);
		
	}
	ListIterator<Integer> data1=list.listIterator();
	
	while (data1.hasNext()) {
		Integer val = (Integer) data1.next();
		
		//System.out.println(val);
		
	}
	while (data1.hasPrevious()) {
		Integer val1 = (Integer) data1.previous();
		//System.out.println(val1);
		
	}
	
	}
	public void vectorlist() {
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(10);
		v.add(11);
		v.add(12);
		
		for(Integer val : v) {
			//System.out.println(val);

			
		}
		
		
		
		Enumeration<Integer> data1=v.elements();
		
		while (data1.hasMoreElements()) {
			Integer val= (Integer) data1.nextElement();
			//System.out.println(val);
			
		}
	}
		
		public void settest() {
		HashSet<Integer> ha=new HashSet<Integer>();
		
		ha.add(1);
		ha.add(2);
		ha.add(3);
		ha.add(null);
		
	
		for (Integer val : ha) {
			System.out.println(val);
			
		}
		
		
}
	

	
	public static void main(String[] args) {
		List11 li=new List11();
		li.arraylist();
		//li.vectorlist();
		//li.settest();
		
	}
}
