package collections1;

import java.util.List;
import java.util.Vector;

public class Vectorlist {
	
	public void vectotest() {
		List<Integer> v=new Vector<Integer>();
		
		v.add(10);
		v.add(11);
		v.add(12);
		
	
		
		
		
		
		
	}
	public static void main(String[] args) {
		
		Vectorlist v1=new Vectorlist();
		v1.vectotest();
	}
	




}
