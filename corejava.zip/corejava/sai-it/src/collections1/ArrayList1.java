package collections1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;

public class ArrayList1 {
	
	
	
	public void arrayListTest() {
		
		
		ArrayList<Integer> ar=new ArrayList<Integer>();
		ar.add(12);
		ar.add(13);
		ar.add(14);
		//System.out.println(ar.get(1));
		
		for (Integer val : ar) {
			//System.out.println(val);
			
		}
		 ListIterator<Integer> ar1=ar.listIterator();
		 
		 while (ar1.hasPrevious()) {
			Integer val = (Integer) ar1.previous();
			System.out.println(val);
			
		}
		
		
		LinkedList<Integer> in=new LinkedList<Integer>();
		in.add(12);
		in.add(14);
		in.add(45);
	//	System.out.println(in.remove(2));
		for (Integer val : in) {
			//System.out.println(val);
			
			
		}
		
		
		
	}
public static void main(String[] args) {
	
	ArrayList1 a1=new ArrayList1();
	a1.arrayListTest();
}
}
