package collections1;

public class Compareble1 {
	
	int pid;
	String pname;
	double 

}
