package encapulation;

public class Unknwon1 {
	public static void main(String[] args) {
		
		AcctHolder ac=new AcctHolder("saikiraN", 232432442, "SABIN002", 10000);
		
		System.out.println(ac.accnum);
		//System.out.println(ac.balance);
		ac.setName("sai d");
		System.out.println(ac.getName());
		
		
	}

}
