package encapulation;

public class AcctHolder {
	
	String name="sai";
	int accnum=123444;
	String ifsc="sbin00023";
	 private double balance=400000;
	public AcctHolder(String name, int accnum, String ifsc, double balance) {
		super();
		this.name = name;
		this.accnum = accnum;
		this.ifsc = ifsc;
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccnum() {
		return accnum;
	}
	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
}