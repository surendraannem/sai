package collections;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class CollectionsTypes {
	
	public void arraylist() {
		
		ArrayList<Integer> ar=new ArrayList<Integer>();
		
		ar.add(10);
		ar.add(12);
		ar.add(14);
		ar.add(20);
		
		for (Integer val : ar) {
			
			//System.out.println(val);
			
		}
		//System.out.println("................");
		Iterator<Integer> ar1=ar.iterator();
		
		while (ar1.hasNext()) {
			Integer val = (Integer) ar1.next();
			//System.out.println(val);
			
		}
		
		ListIterator<Integer>ar2=ar.listIterator();
		
		while (ar2.hasNext()) {
			Integer val = (Integer) ar2.next();
			System.out.println(val);
			
		}
		while (ar2.hasPrevious()) {
			Integer val = (Integer) ar2.previous();
			System.out.println(val);
			
		}
		

}
	
	
	public void vectorlist() {
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(11);
		v.add(12);
		v.add(13);
		v.add(14);
		
		Enumeration<Integer> v1=v.elements();
		
		while (v1.hasMoreElements()) {
			Integer val = (Integer) v1.nextElement();
			System.out.println(val);
			
		}
			
		}
		
	
public static void main(String[] args) {
	
	CollectionsTypes ct=new CollectionsTypes();
	//ct.arraylist();
	ct.vectorlist();
	
}	
	
}