package methods;

public class MethodsTest {
	public static void main(String[] args) {
		System.out.println("Welcome to Sai java ");
	
	}

}
